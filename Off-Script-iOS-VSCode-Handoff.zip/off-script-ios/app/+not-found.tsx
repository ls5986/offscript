import { useRouter } from "expo-router";
import { Button, Page, Title } from "../src/design/ui";
export default function Missing() {
  const r = useRouter();
  return (
    <Page>
      <Title eyebrow="A LITTLE OFF SCRIPT" title="Let's find your way back." />
      <Button onPress={() => r.replace("/")}>Go home</Button>
    </Page>
  );
}
