> **Native iOS handoff:** start with [START_HERE_IOS.md](START_HERE_IOS.md). This checkout contains the latest 2.3.0 content review plus native release preparation. The existing public website is a separate deployment; this package does not publish changes to it.

# Off Script

Version 1.3 makes **Party Night** and **Prompt Studio** the flagship experiences, with the full 39-game catalog in Explore. Read [the product update](docs/PARTY_NIGHT.md) and [architecture decision](docs/ADR_PARTY_NIGHT.md).

Export the current complete prompt/game inventory with `npx tsx scripts/export-content.ts <output.md>`.

Playable, offline-first improv party app for iOS and web. One Expo Router / React Native codebase, one bundled content pack, no backend, account, tracking SDK, or runtime AI.

## Play

The browser build is publicly hosted with Sites at https://off-script-play.lindsey08092.chatgpt.site . The deployment URL is recorded in `docs/BUILD_REPORT.md` after deployment succeeds. For local use:

```bash
npm ci
npm run web
```

Expo prints the local development address. That address is reachable only from the machine or network running the server. To serve the production export:

```bash
npm run build:web
node scripts/serve.mjs
# http://localhost:4173
```

## What is implemented

- Surprise Me, remembered count, optional names, 2–12 players, indefinite rounds and session resume.
- Five curated session policies plus standalone Prompt Studio; 39 runnable activity formats across ten engine families.
- Seeded eligibility/selection, exposure-aware casting, partner-repeat penalties, support roles, sitting out and group resizing.
- Ten Studio categories, coherent/independent generation, exact locks, individual rerolls, scalable relationships, teacher/custom presets, save/share, history, and exact Scene Lab handoff.
- Automatic/manual visual cues, optional speech/haptics, centralized pause-safe timer, Half-Life segments, private pass-and-hide objectives/quirks, turn tracking, replacement/relay mechanics, individual/team points and human votes.
- IndexedDB browser persistence and native SQLite migration/projections; safe paused restore; favorites, snapshots, local deletion, coaching, large display/text, keyboard focus, system dark mode.
- Content quotas: 1,182 Studio ingredients, 96 structured relationships, 160 joke topics with explicit plurals, 60 objectives, 40 quirks, 161 possible emotion/genre/line cues.
- Web production export with service-worker precaching. First visit requires network; offline reload/play is tested after caching. Browser data may be cleared or restricted by the browser/user.

## Checks

```bash
npm run typecheck
npm run lint
npm run content:validate
npm test
npm run test:e2e:web
npm run doctor
npm run build:web
```

Playwright uses `/usr/bin/chromium` in this workspace. Elsewhere, set `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` to a Chromium installation or adapt the config to Playwright's installed browser. `tests/e2e` exercises the actual exported app. See `docs/BUILD_REPORT.md` for executed checks and exceptions.

## iOS

```bash
npx expo start --ios
# macOS + Xcode needed for a simulator
npx expo run:ios
# after owner configures bundle ID, EAS project and Apple signing:
npx eas-cli@latest build --platform ios --profile production
npx eas-cli@latest submit --platform ios
```

The JavaScript/Hermes iOS bundle exports on Linux. That does **not** establish an IPA build, simulator/device validation, signing, or TestFlight upload. See `docs/APP_STORE_READINESS.md` and the release runbook.

## Sources and architecture

- `docs/PRD.md`: supplied master requirements.
- `src/domain/contracts.ts` and `contracts/domain.schemas.ts`: synchronized canonical schemas plus the movement-exclusion setting.
- `content/activities.v1.json` and `src/content/v1/activities.json`: synchronized authored catalog; Open Scene's ensemble ceiling is 12 for Studio handoff.
- `database/001_init.sql`: canonical version-1 native migration. `src/storage/migration.ts` contains the identical SQL for Metro bundling.
- `src/domain/session.ts`: deterministic casting, selection, schedules, lifecycle reducer, and timer math.
- `src/domain/prompts.ts`: local prompt generation, locks, cycles and structured roles.
- `src/storage`: validated repositories and versioned aggregate storage.
- `scripts/author-content.py`: auditable original authoring source for bundled banks; no runtime generation service.

Private objectives are never included in shared Studio copy, history summaries or recaps. They stay in local session storage for crash recovery, and only the named recipient sees each reveal.
