# Off Script — start here in VS Code

This is the native iOS handoff of the working Off Script app, including content pack 2.3.0 and the complete ingredient review. It is already React Native / Expo: continue this app rather than wrapping the website in a WebView or rewriting the game engines.

Recommended first release: **no account, device-only saves**. Names, prompts, favorites and sessions are useful local data; they do not require a cloud database or login. Every group member remains a guest. The separate live website has not been changed by this native preparation.

## Open and run

1. Unzip this package and open its `off-script-ios` folder in VS Code.
2. Use Node 24.3 or newer in the Node 24 line (`nvm use` with the included `.nvmrc`).
3. Run:

```bash
npm ci
npm run typecheck
npm test
npm run ios:check
npm start
```

For a Mac with Xcode and an installed iOS simulator:

```bash
npm run ios:simulator
# or generate and compile a native development app:
npm run ios
```

The current SDK-generated native target defaults to iOS 16.4; verify that minimum against the intended audience before distribution. A simulator/local native compile needs macOS/Xcode. EAS can build iOS in the cloud from other operating systems, but signing and real-device testing still require the owner's Apple/Expo setup. The development-client package and simulator/device/production profiles are included.

## Configure your identity and public pages

Copy `.env.example` to `.env.local`. Fill the four required public values from your own accounts/pages:

- `OFFSCRIPT_IOS_BUNDLE_ID`: the bundle identifier you select/register with Apple. Choose it carefully; an App Store app's identifier is not a casual rename.
- `OFFSCRIPT_EAS_PROJECT_ID`: the UUID from your Expo/EAS project.
- `OFFSCRIPT_PRIVACY_URL`: a real, approved public HTTPS privacy policy.
- `OFFSCRIPT_SUPPORT_URL`: a real public HTTPS support page.

`OFFSCRIPT_APPLE_TEAM_ID` is optional when EAS can select the authorized team interactively. `app.config.ts` also accepts equivalent values in `app.json`: `ios.bundleIdentifier`, `extra.eas.projectId`, `extra.release.privacyURL`, and `extra.release.supportURL`. No owner identifiers or legal URLs have been invented for you.

Authenticate and connect your own Expo/EAS account, inspect its project, and use its project ID. Configure these public metadata variables in that project's EAS environments too, because `.env.local` is excluded from build uploads. Start with the preview environment and repeat for production. Apple signing keys/certificates and account credentials belong in EAS/Apple credential management, not source, `.env.example`, or `EXPO_PUBLIC_*` variables.

```bash
npx eas-cli@latest login
npx eas-cli@latest init
npm run ios:check -- --release
npm run ios:build:preview
```

`preview` builds for the simulator. `device` is an internal build for registered physical devices; EAS will guide device registration/signing. `development` includes the native development client. `production` is for TestFlight/App Store binaries, with remote build-number incrementing. Production configuration fails early if required owner metadata is missing. The shared EAS base profile pins Node 24.19.0; the package lockfile fixes app dependencies.

```bash
npm run ios:build:production
```

Create the matching app record in App Store Connect. Add its numeric ID to `submit.production.ios.ascAppId` in `eas.json`, then:

```bash
npm run ios:submit
```

Submission uploads a selected build to App Store Connect/TestFlight; it does not replace metadata review, tester validation, App Review submission or release. Keep those final distribution decisions with the owner.

## What has been prepared

- One shared game/content engine; 39 games, Party Night, Studio, all current corrections.
- Existing native SQLite repository, versioned Zod snapshots, safe paused restore, exact saved ingredient/lock provenance, and local deletion.
- Native build configuration with a guest/local policy, public privacy/support link wiring, no tracking declaration, standard encryption exemption flag and protected app-container sharing settings.
- SDK privacy-manifest aggregation retained. Third-party required-reason API declarations must be inspected in the final built archive.
- No Apple login entitlement, cloud account, paid service, analytics or new runtime server.
- A release configuration check, meaningful native-configuration tests, and build profiles.

Settings shows the configured Privacy policy and Support links in native builds. The production check requires both URLs. This package provides implementation and policy guidance; the owner must supply and approve the real policy/contact information.

Read [verification and remaining work](docs/ios/VERIFICATION.md), [data architecture](docs/ios/DATA_AND_SYNC.md), [Apple sign-in decision](docs/ios/APPLE_SIGN_IN.md), and [release checklist](docs/ios/RELEASE_CHECKLIST.md). Give your VS Code coding assistant [VSCODE_IOS_PROMPT.md](VSCODE_IOS_PROMPT.md) after opening the folder.
