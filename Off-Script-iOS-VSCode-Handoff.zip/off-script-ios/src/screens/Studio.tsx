import { Feedback } from "../components/Feedback";
import { ComposedPrompt } from "../components/ComposedPrompt";
import {
  composeScene,
  legacyIngredientCategories,
  refreshComposition,
  upgradeSnapshotIngredients,
} from "../domain/composer";
import { useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Platform, Share, View } from "react-native";
import {
  Button,
  Card,
  Chip,
  Counter,
  Dialog,
  Eyebrow,
  Field,
  Icon,
  IconButton,
  Page,
  Row,
  Txt,
  useTheme,
} from "../design/ui";
import {
  categories,
  Category,
  categoryLabels,
  relationships,
} from "../domain/content";
import { Player, PromptSnapshot } from "../domain/contracts";
import {
  generatePrompt,
  promptText,
  relationshipCompatible,
  snapshotIsClean,
} from "../domain/prompts";
import { seededRng } from "../domain/random";
import { useApp, uuid } from "../providers/AppProvider";
const presets: [string, Category[]][] = [
  ["Who / What / Where", ["relationship", "action", "location"]],
  ["Relationship Only", ["relationship"]],
  ["Emotion + Action", ["emotion", "action"]],
  ["Blank Canvas", []],
];
export function PromptCards({
  snapshot,
  large = false,
  controls,
  onLock,
  onReroll,
  players,
}: {
  snapshot: PromptSnapshot;
  players?: Player[];
  large?: boolean;
  controls?: boolean;
  onLock?: (c: Category) => void;
  onReroll?: (c: Category) => void;
}) {
  const t = useTheme();
  return (
    <View
      style={{
        flexDirection: large ? "column" : "row",
        flexWrap: "wrap",
        gap: 16,
      }}
    >
      {Object.entries(snapshot.entries).map(([key, v]) => (
        <Card
          key={key}
          style={{
            flexBasis: large ? "auto" : 280,
            flexGrow: 1,
            padding: large ? 35 : 23,
            backgroundColor:
              key === "relationship"
                ? t.lilac
                : key === "location"
                  ? t.blue
                  : t.card,
          }}
        >
          <Row style={{ justifyContent: "space-between" }}>
            <Eyebrow>
              {legacyIngredientCategories(snapshot).includes(key as Category)
                ? `Saved original · ${categoryLabels[key as Category]}`
                : categoryLabels[key as Category]}
            </Eyebrow>
            {controls && (
              <Row style={{ gap: 0 }}>
                <IconButton
                  name={v.locked ? "lock" : "unlock"}
                  active={v.locked}
                  label={`${v.locked ? "Unlock" : "Lock"} ${categoryLabels[key as Category]}`}
                  onPress={() => onLock?.(key as Category)}
                />
                <IconButton
                  name="refresh"
                  label={`Reroll ${categoryLabels[key as Category]}`}
                  onPress={() => {
                    if (!v.locked) onReroll?.(key as Category);
                  }}
                  disabled={v.locked}
                />
              </Row>
            )}
          </Row>
          <Txt
            serif
            size={large ? 42 : 25}
            style={{ lineHeight: large ? 54 : 35 }}
          >
            {v.text}
          </Txt>
          {key === "relationship" && snapshot.relationship && (
            <View style={{ gap: 5, paddingTop: 6 }}>
              {snapshot.relationship.assignments.map((r, i) => (
                <Txt key={i} size={large ? 19 : 14} muted>
                  {players?.find((p) => p.id === r.playerId)?.displayName ??
                    players?.find(
                      (p) =>
                        p.seatIndex ===
                        Number(r.playerId.replace("Player ", "")) - 1,
                    )?.displayName ??
                    `Player ${i + 1}`}{" "}
                  · {r.roleText}
                </Txt>
              ))}
            </View>
          )}
        </Card>
      ))}
    </View>
  );
}
export default function Studio() {
  const { data, update, ready } = useApp();
  const { studio } = data;
  const legacyCategories = studio.result
    ? legacyIngredientCategories(studio.result)
    : [];
  const legacyLocked = legacyCategories.some(
    (c) => studio.result?.entries[c].locked,
  );
  const router = useRouter();
  const t = useTheme();
  const [large, setLarge] = useState(false);
  const [toast, setToast] = useState("");
  const [warning, setWarning] = useState("");
  const [label, setLabel] = useState("My scene recipe");
  const [presetOpen, setPresetOpen] = useState(false);
  const initial = useRef(false);
  const [customize, setCustomize] = useState(false);
  const generate = useCallback(
    async (
      only?: Category,
      selected?: Category[],
      flavor?: "playful" | "grounded",
    ) => {
      await update((d) => {
        const cats = selected ?? d.studio.categories;
        const { snapshot, usage } = generatePrompt(
          {
            categories: cats,
            count: d.studio.playerCount,
            flavor: flavor ?? d.studio.flavor,
            style: d.studio.generationStyle,
            previous: d.studio.result,
            only,
            usage: d.usage,
          },
          seededRng(Date.now() >>> 0),
        );
        snapshot.jokeTopic = null;
        const entry = {
          id: uuid(),
          createdAt: new Date().toISOString(),
          label: "Recent inspiration",
          snapshot,
          playerCount: d.studio.playerCount,
        };
        return {
          ...d,
          studio: {
            ...d.studio,
            flavor: flavor ?? d.studio.flavor,
            categories: cats,
            result: snapshot,
          },
          usage,
          promptHistory: [entry, ...d.promptHistory].slice(0, 30),
        };
      });
      setToast("");
    },
    [update],
  );
  useEffect(() => {
    if (!ready || initial.current) return;
    initial.current = true;
    if (!studio.result)
      queueMicrotask(() => {
        void generate();
      });
  }, [ready, studio.result, generate]);
  const toggle = async (c: Category) => {
    await update((d) => {
      const active = d.studio.categories.includes(c);
      const cats = active
        ? d.studio.categories.filter((x) => x !== c)
        : [...d.studio.categories, c];
      const result = structuredClone(d.studio.result);
      if (active && result) {
        delete result.entries[c];
        if (c === "relationship") result.relationship = null;
        return {
          ...d,
          studio: {
            ...d.studio,
            categories: cats,
            result: result ? refreshComposition(result) : result,
          },
        };
      }
      const { snapshot, usage } = generatePrompt(
        {
          categories: cats,
          count: d.studio.playerCount,
          style: d.studio.generationStyle,
          previous: result,
          flavor: d.studio.flavor,
          only: c,
          usage: d.usage,
        },
        seededRng(Date.now() >>> 0),
      );
      return {
        ...d,
        studio: { ...d.studio, categories: cats, result: snapshot },
        usage,
      };
    });
  };
  const lock = async (c: Category) => {
    await update((d) => {
      const result = structuredClone(d.studio.result);
      if (result?.entries[c])
        result.entries[c].locked = !result.entries[c].locked;
      return {
        ...d,
        studio: {
          ...d.studio,
          result: result ? refreshComposition(result) : result,
        },
      };
    });
  };
  const count = async (n: number) => {
    if (
      studio.result?.entries.relationship?.locked &&
      studio.result.relationship?.assignments.length !== n
    ) {
      setWarning(
        "Unlock Relationship before changing the performer count. Its saved role assignments will stay intact until you do.",
      );
      return;
    }
    await update((d) => {
      let result = structuredClone(d.studio.result);
      if (result?.relationship) {
        if (!relationshipCompatible(result, n)) {
          delete result.entries.relationship;
          result.relationship = null;
        } else {
          const template = relationships.find(
            (r) => r.id === result?.relationship?.templateId,
          )!;
          result.relationship.assignments = Array.from(
            { length: n },
            (_, i) => ({
              playerId: `Player ${i + 1}`,
              roleText:
                template.namedRoles[i] ??
                `${template.expandableRole} ${i - template.namedRoles.length + 1}`,
            }),
          );
        }
      }
      return {
        ...d,
        studio: {
          ...d.studio,
          playerCount: n,
          result: result ? refreshComposition(result) : result,
        },
      };
    });
    setWarning("");
    if (
      studio.categories.includes("relationship") &&
      !relationshipCompatible(studio.result, n)
    )
      await generate("relationship");
  };
  const save = async () => {
    if (!studio.result) return;
    await update((d) => ({
      ...d,
      savedPrompts: [
        {
          id: uuid(),
          createdAt: new Date().toISOString(),
          label: "A scene worth keeping",
          snapshot: refreshComposition(structuredClone(d.studio.result!)),
          playerCount: d.studio.playerCount,
        },
        ...d.savedPrompts,
      ],
    }));
    setToast("Saved exactly as you see it.");
  };
  const copy = async () => {
    if (!studio.result) return;
    const text =
      promptText(studio.result) || "An open scene. Start with an offer.";
    try {
      if (Platform.OS === "web" && navigator.clipboard) {
        await navigator.clipboard.writeText(text);
        setToast("Copied. Go make something.");
      } else await Share.share({ message: text });
    } catch {
      setToast(
        "Sharing is unavailable here. Your cards are still saved locally.",
      );
    }
  };
  if (
    data.preferences.classroomDefault &&
    studio.result &&
    !snapshotIsClean(studio.result)
  )
    return (
      <Page narrow>
        <Txt serif size={32}>
          Prompt Studio
        </Txt>
        <Card>
          <Txt>This saved prompt is hidden while Classroom clean is on.</Txt>
          <Button
            onPress={() => {
              void update((d) => ({
                ...d,
                studio: { ...d.studio, result: null },
              })).then(() => generate());
            }}
          >
            Generate clean ingredients
          </Button>
          <Txt muted size={14}>
            Your saved original stays unchanged.
          </Txt>
        </Card>
      </Page>
    );
  return (
    <Page
      compact
      presentation={large}
      dock={
        !large ? (
          <Row
            style={{
              width: "100%",
              maxWidth: 1160,
              alignSelf: "center",
              flexWrap: "nowrap",
              gap: 8,
            }}
          >
            <Button
              icon="shuffle"
              style={{ flex: 1, paddingHorizontal: 15 }}
              onPress={() => void generate()}
            >
              Generate Again
            </Button>
            <Button
              kind="secondary"
              icon="settings"
              onPress={() => setCustomize(true)}
            >
              Customize
            </Button>
          </Row>
        ) : undefined
      }
    >
      <Row style={{ justifyContent: "space-between" }}>
        <Txt serif size={large ? 45 : 34}>
          Prompt Studio
        </Txt>
        <IconButton
          name={large ? "close" : "expand"}
          label={large ? "Exit display" : "Large Display"}
          onPress={() => setLarge(!large)}
        />
      </Row>
      {!large && (
        <>
          <Txt muted size={15}>
            A starting point, not a script. Lock what you love.
          </Txt>
          <Row>
            <Chip
              selected={studio.flavor === "playful"}
              onPress={() => void generate(undefined, undefined, "playful")}
            >
              Playful
            </Chip>
            <Chip
              selected={studio.flavor === "grounded"}
              onPress={() => void generate(undefined, undefined, "grounded")}
            >
              Grounded
            </Chip>
            <Chip icon="people" onPress={() => setCustomize(true)}>
              {studio.playerCount} performers
            </Chip>
          </Row>
        </>
      )}
      {!large && (
        <Row>
          <Chip
            selected={
              studio.categories.length === 1 &&
              studio.categories[0] === "relationship"
            }
            onPress={() => void generate(undefined, ["relationship"])}
          >
            Relationship only
          </Chip>
          <Chip
            selected={
              studio.categories.length === 1 &&
              studio.categories[0] === "location"
            }
            onPress={() => void generate(undefined, ["location"])}
          >
            Location only
          </Chip>
        </Row>
      )}
      {legacyCategories.length > 0 && (
        <Card style={{ backgroundColor: t.blue }}>
          <Eyebrow>SAVED ORIGINAL</Eyebrow>
          <Txt size={15}>
            These saved words combine ingredients from an earlier content pack.
            Your original text and locks stay exact.
          </Txt>
          <Txt size={14} muted>
            {legacyLocked
              ? "Unlock the saved originals before updating their ingredients."
              : "Update this editable copy to use pure ingredients and the scene composer. Your saved original stays unchanged."}
          </Txt>
          <Button
            kind="secondary"
            disabled={legacyLocked}
            onPress={() =>
              void update((d) => ({
                ...d,
                studio: {
                  ...d.studio,
                  result: d.studio.result
                    ? upgradeSnapshotIngredients(d.studio.result)
                    : null,
                },
              }))
            }
          >
            Update ingredients
          </Button>
        </Card>
      )}
      {studio.result?.jokeTopic ? (
        <Card style={{ backgroundColor: t.lilac }}>
          <Eyebrow>SAVED WORD</Eyebrow>
          <Txt serif size={38}>
            {studio.result.jokeTopic.word}
          </Txt>
          <Txt muted size={14}>
            Choose ingredients or Generate Again for a new scene.
          </Txt>
        </Card>
      ) : studio.categories.length === 0 ? (
        <Card
          style={{
            minHeight: 180,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Icon name="theater" size={28} />
          <Txt serif size={30}>
            The stage is yours.
          </Txt>
          <Txt muted>No prompts. Make a simple offer.</Txt>
        </Card>
      ) : (
        studio.result && (
          <>
            <ComposedPrompt snapshot={studio.result} large={large} />
            {composeScene(studio.result) && <Eyebrow>YOUR INGREDIENTS</Eyebrow>}
            <PromptCards
              snapshot={studio.result}
              large={large}
              controls={!large}
              onLock={(c) => void lock(c)}
              onReroll={(c) => void generate(c)}
            />
          </>
        )
      )}
      {toast && (
        <Txt
          accessibilityLiveRegion="polite"
          size={14}
          style={{ color: t.accentInk }}
        >
          {toast}
        </Txt>
      )}
      <Row>
        <Button
          icon="play"
          onPress={() =>
            router.push({
              pathname: "/start",
              params: {
                mode: "scene_lab",
                activity: "S1",
                studio: "1",
                intent: studio.flavor === "playful" ? "riff" : "practice",
              },
            })
          }
        >
          Use in Scene Lab
        </Button>
        <Button kind="secondary" icon="bookmark" onPress={() => void save()}>
          Save prompt
        </Button>
        <Button kind="ghost" icon="copy" onPress={() => void copy()}>
          Copy / Share
        </Button>
      </Row>
      {studio.result && (
        <Feedback
          activityId="studio"
          roundId="studio"
          snapshot={studio.result}
        />
      )}
      {!large && (
        <Txt muted size={14}>
          {studio.categories.length} ingredients ·{" "}
          {studio.flavor === "playful"
            ? "One playful twist to get you talking."
            : "Grounded scenes with room to discover something."}
        </Txt>
      )}
      <Dialog
        visible={customize}
        onClose={() => setCustomize(false)}
        title="Your scene recipe"
      >
        <Txt size={14} muted>
          Choose any ingredients. Toggling one keeps the rest of your scene
          intact.
        </Txt>
        <Row>
          {categories.map((c) => (
            <Chip
              key={c}
              selected={studio.categories.includes(c)}
              icon={studio.categories.includes(c) ? "check" : "plus"}
              onPress={() => void toggle(c)}
            >
              {categoryLabels[c]}
            </Chip>
          ))}
        </Row>
        <Eyebrow>HOW TO MIX</Eyebrow>
        <Row>
          <Chip
            selected={studio.generationStyle === "coherent"}
            onPress={() =>
              void update((d) => ({
                ...d,
                studio: { ...d.studio, generationStyle: "coherent" },
              }))
            }
          >
            Connected ideas
          </Chip>
          <Chip
            selected={studio.generationStyle === "independent"}
            onPress={() =>
              void update((d) => ({
                ...d,
                studio: { ...d.studio, generationStyle: "independent" },
              }))
            }
          >
            Mix freely
          </Chip>
        </Row>
        <Txt size={14} muted>
          Connected ideas prioritizes curated matches and shared settings. Mix
          freely permits unexpected combinations. Only your selected ingredients
          appear; locks always come first.
        </Txt>
        <Eyebrow>PERFORMERS</Eyebrow>
        <Counter count={studio.playerCount} onChange={(n) => void count(n)} />
        {warning && <Txt style={{ color: t.accentInk }}>{warning}</Txt>}
        <Eyebrow>TEACHER PRESETS</Eyebrow>
        <Row>
          {presets.map(([name, cats]) => (
            <Chip
              key={name}
              onPress={() => {
                void generate(undefined, cats);
              }}
            >
              {name}
            </Chip>
          ))}
          <Chip
            icon="plus"
            onPress={() => {
              setCustomize(false);
              setPresetOpen(true);
            }}
          >
            Save my preset
          </Chip>
        </Row>
        {data.presets.length > 0 && (
          <Row>
            {data.presets.map((p) => (
              <Chip
                key={p.id}
                onPress={() => void update((d) => ({ ...d, studio: p.state }))}
              >
                {p.label}
              </Chip>
            ))}
          </Row>
        )}
        <Button onPress={() => setCustomize(false)}>Done</Button>
      </Dialog>
      <Dialog
        visible={presetOpen}
        onClose={() => setPresetOpen(false)}
        title="Save your recipe"
      >
        <Field label="Preset name" value={label} onChangeText={setLabel} />
        <Button
          onPress={() => {
            void update((d) => ({
              ...d,
              presets: [
                ...d.presets,
                {
                  id: uuid(),
                  label: label.trim() || "My scene recipe",
                  state: structuredClone(d.studio),
                },
              ],
            }));
            setPresetOpen(false);
          }}
        >
          Save preset
        </Button>
      </Dialog>
    </Page>
  );
}
