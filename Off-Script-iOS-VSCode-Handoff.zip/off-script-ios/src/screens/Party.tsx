import { useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import * as Speech from "expo-speech";
import React, { useEffect, useRef, useState } from "react";
import { AppState, Platform, View } from "react-native";
import { PartyOptionsFields, levelLabel } from "../components/PartyOptions";
import { FeedbackChoices } from "../components/Feedback";
import { PartyDeckCard } from "../components/PartyDeckCard";
import { BrandMark } from "../design/brand";
import {
  Button,
  Card,
  Dialog,
  Eyebrow,
  Field,
  IconButton,
  Page,
  Row,
  Title,
  Toggle,
  Txt,
  useTheme,
} from "../design/ui";
import { activityById } from "../domain/content";
import { bookFor } from "../domain/playbooks";
import {
  appendPartyCard,
  editPartyRoster,
  compatiblePartyRecipes,
  normalizePartyOptions,
  partyCardAllowed,
  passPartyTurn,
  rerollPartyPrompt,
  setPartySittingOut,
  partyPlayers,
  partyTurnPlayer,
  nextPartyTurn,
  type PartyPlayerDraft,
} from "../domain/party";
import { recipeById } from "../domain/party-recipes";
import type { PartyOptions } from "../domain/party-contracts";
import { currentRound, type GameAction } from "../domain/session";
import { useApp, uuid } from "../providers/AppProvider";
export default function Party() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const {
    data,
    ready,
    act,
    advanceParty,
    editPartyPlayers,
    changeSession,
    update,
    favorite,
  } = useApp();
  const router = useRouter();
  const t = useTheme();
  const s = data.sessions.find((s) => s.id === id);
  const [sheet, setSheet] = useState<
    "more" | "rules" | "players" | "preferences" | "feedback" | "games" | null
  >(null);
  const [largeDisplay, setLargeDisplay] = useState(false);
  const [roster, setRoster] = useState<PartyPlayerDraft[]>([]);
  const [editingPlayers, setEditingPlayers] = useState(false);
  const [draft, setDraft] = useState<PartyOptions | null>(null);
  const [secretVisible, setSecretVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const working = useRef(false);
  const [toast, setToast] = useState("");
  const [error, setError] = useState("");
  useFocusEffect(
    React.useCallback(
      () => () => {
        setSecretVisible(false);
        Speech.stop();
        if (id) void act(id, { type: "PAUSE" });
      },
      [id, act],
    ),
  );
  useEffect(() => {
    const cover = () => setSecretVisible(false);
    const sub = AppState.addEventListener("change", (state) => {
      if (state !== "active") cover();
    });
    const hide = () => {
      if (document.hidden) cover();
    };
    if (Platform.OS === "web")
      document.addEventListener("visibilitychange", hide);
    return () => {
      sub.remove();
      if (Platform.OS === "web")
        document.removeEventListener("visibilitychange", hide);
    };
  }, []);
  useEffect(() => {
    if (!secretVisible) return;
    const timeout = setTimeout(() => setSecretVisible(false), 20000);
    return () => clearTimeout(timeout);
  }, [secretVisible]);
  const safely = async (fn: () => Promise<void>) => {
    if (working.current) return;
    working.current = true;
    setBusy(true);
    setError("");
    try {
      await fn();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save that change.");
    } finally {
      working.current = false;
      setBusy(false);
    }
  };
  if (!ready)
    return (
      <Page>
        <Txt>Opening your party…</Txt>
      </Page>
    );
  if (!s?.party)
    return (
      <Page>
        <Title eyebrow="PARTY NIGHT" title="Bring your people." />
        <Button onPress={() => router.replace("/party")}>Start a party</Button>
      </Page>
    );
  const r = currentRound(s);
  const a = activityById(r.activityId);
  const card = s.party.cards.at(-1)!;
  const recipe = recipeById(card.recipeId);
  const allowed = partyCardAllowed(s, data.preferences.classroomDefault);
  const name = (pid: string) =>
    partyPlayers(s).find((p) => p.id === pid)?.displayName ?? "Player";
  const live = r.status === "live";
  const turnPlayer = partyTurnPlayer(s);
  const paused = r.status === "paused" || s.status === "paused";
  const rolePlayerIds = [...r.performerIds, ...r.supportingPlayerIds];
  const required =
    typeof recipe?.performers === "number" ? recipe.performers : 1;
  const needsPlayers =
    rolePlayerIds.length < required ||
    (recipe?.performers !== "everyone" &&
      s.party.passedPlayerIds.some((pid) =>
        r.secrets.some((secret) => secret.playerId === pid),
      ));
  const action = (action: GameAction) => void safely(() => act(id, action));
  const advance = (options: Parameters<typeof advanceParty>[1] = {}) =>
    void safely(async () => {
      setSecretVisible(false);
      Speech.stop();
      await advanceParty(id, options);
      setToast("");
      setSheet(null);
    });
  const open = (value: typeof sheet) =>
    void safely(async () => {
      setSecretVisible(false);
      // Untimed social cards keep flowing after a quick menu visit. Timed/secret scenes pause safely.
      if (r.schedule.length || r.remainingMs > 0 || r.secrets.length)
        await act(id, { type: "PAUSE" });
      if (value === "players") {
        setRoster(s.players.map((p) => ({ id: p.id, name: p.displayName })));
        setEditingPlayers(false);
      }
      if (value === "preferences")
        setDraft(
          normalizePartyOptions(
            s.party!.options,
            data.preferences.classroomDefault,
          ),
        );
      setSheet(value);
    });
  const start = () =>
    void safely(async () => {
      if (r.status === "intro") await act(id, { type: "READY" });
      if (!r.secrets.length || r.status === "ready")
        await act(id, { type: "START" });
    });
  const end = () =>
    void safely(async () => {
      setSecretVisible(false);
      Speech.stop();
      await changeSession(id, (session) => ({
        ...session,
        status: "finished",
        rounds: session.rounds.map((round, i) =>
          i === session.rounds.length - 1
            ? {
                ...round,
                status: "complete",
                completedAt: new Date().toISOString(),
              }
            : round,
        ),
        party: {
          ...session.party!,
          cards: session.party!.cards.map((c, i) =>
            i === session.party!.cards.length - 1
              ? { ...c, disposition: "played" }
              : c,
          ),
        },
      }));
      setSheet(null);
    });
  const save = () =>
    void safely(async () => {
      await update((d) => {
        if (
          d.savedPrompts.some(
            (p) =>
              JSON.stringify(p.snapshot) === JSON.stringify(r.promptSnapshot),
          )
        )
          return d;
        return {
          ...d,
          savedPrompts: [
            {
              id: uuid(),
              label: a.title,
              createdAt: new Date().toISOString(),
              snapshot: structuredClone(r.promptSnapshot),
              playerCount: Math.max(2, rolePlayerIds.length),
            },
            ...d.savedPrompts,
          ],
        };
      });
      setSheet(null);
      setToast("Prompt saved on this device.");
    });
  if (s.status === "finished")
    return (
      <Page narrow>
        <Title
          eyebrow="PARTY NIGHT · YOUR RECAP"
          title="That was all you."
          sub={`${s.players.length} people · ${s.party.cards.filter((c) => c.disposition === "played").length} cards played.`}
        />
        <Card>
          <Eyebrow>THE LINEUP</Eyebrow>
          {s.rounds
            .filter((round) => round.status !== "skipped")
            .map((round) => (
              <Row key={round.id} style={{ justifyContent: "space-between" }}>
                <Txt>{activityById(round.activityId).title}</Txt>
                <Txt muted size={13}>
                  {round.performerIds
                    .map(
                      (pid) =>
                        s.party!.cards.find((c) => c.roundId === round.id)
                          ?.playerNames?.[pid] ?? name(pid),
                    )
                    .join(", ")}
                </Txt>
              </Row>
            ))}
        </Card>
        <Field
          label="Session highlight"
          placeholder="A line worth remembering?"
          value={s.note}
          multiline
          onChangeText={(note) =>
            void changeSession(id, (session) => ({
              ...session,
              note: note.slice(0, 500),
            }))
          }
        />
        <Button icon="shuffle" onPress={() => router.replace("/party")}>
          Another party
        </Button>
        <Button kind="secondary" onPress={() => router.replace("/")}>
          Home
        </Button>
      </Page>
    );
  return (
    <Page
      narrow
      compact
      play
      presentation={largeDisplay}
      dock={
        <View style={{ gap: 8 }}>
          {allowed &&
            live &&
            !needsPlayers &&
            card.pattern === "CUED_SCENE" && (
              <Button
                small
                kind="coral"
                onPress={() => action({ type: "CALL_CUE" })}
              >
                {a.id === "G2"
                  ? "New Choice!"
                  : a.id === "G3"
                    ? "New emotion"
                    : "New genre"}
              </Button>
            )}
          <View accessibilityLiveRegion="polite">
            {allowed &&
              r.cue &&
              (r.cue.type === "stop" ||
                r.elapsedMs - r.cue.atElapsedMs < r.cue.displayDurationMs) && (
                <Txt
                  testID="party-cue"
                  size={19}
                  weight="bold"
                  style={{ textAlign: "center", color: t.accentInk }}
                >
                  {r.cue.text}
                </Txt>
              )}
          </View>
          <Row
            style={{
              width: "100%",
              maxWidth: 740,
              alignSelf: "center",
              flexWrap: "nowrap",
              gap: 8,
            }}
          >
            <Button
              kind="secondary"
              disabled={busy || !allowed || r.status === "private_reveal"}
              style={{ flex: 1, paddingHorizontal: 10 }}
              onPress={() =>
                void safely(() => changeSession(id, rerollPartyPrompt))
              }
            >
              {r.promptSnapshot.jokeTopic ? "New Word" : "New Prompt"}
            </Button>
            <Button
              icon="arrow"
              disabled={busy}
              style={{ flex: 1, paddingHorizontal: 14 }}
              onPress={() => advance()}
            >
              Next Card
            </Button>
          </Row>
          <Row style={{ justifyContent: "space-between", gap: 6 }}>
            <Button
              small
              kind="ghost"
              disabled={busy}
              onPress={() => advance({ skip: true })}
            >
              Skip card
            </Button>
            {live && (
              <Button
                small
                kind="ghost"
                onPress={() => action({ type: "PAUSE" })}
              >
                Pause
              </Button>
            )}
            <Button small kind="ghost" onPress={() => open("rules")}>
              How to Play
            </Button>
          </Row>
        </View>
      }
    >
      <Row style={{ justifyContent: "space-between", flexWrap: "nowrap" }}>
        <Row style={{ gap: 8, flexWrap: "nowrap", flex: 1 }}>
          <BrandMark size={26} />
          <Eyebrow>PARTY NIGHT</Eyebrow>
        </Row>
        <IconButton
          name="people"
          label="Change players"
          onPress={() => open("players")}
        />
        <Button kind="ghost" small onPress={() => open("preferences")}>
          {levelLabel(s.party.options.level)}
        </Button>
        <IconButton
          name="settings"
          label="Party menu"
          onPress={() => open("more")}
        />
      </Row>
      {error && (
        <Txt accessibilityLiveRegion="polite" style={{ color: t.accentInk }}>
          {error}
        </Txt>
      )}
      {!allowed ? (
        <Card>
          <Txt>This card is hidden by your current content settings.</Txt>
          <Button onPress={() => advance({ skip: true })}>
            Deal an eligible card
          </Button>
        </Card>
      ) : (
        <PartyDeckCard
          session={s}
          large={largeDisplay}
          privateContent={
            r.status === "private_reveal" ? (
              <View style={{ gap: 18 }}>
                <Eyebrow>PRIVATE HANDOFF</Eyebrow>
                <Txt serif size={28}>
                  Only {name(r.secrets[r.revealIndex]?.playerId)} should look.
                </Txt>
                <Txt size={18}>
                  {secretVisible
                    ? r.secrets[r.revealIndex]?.text
                    : "Everyone else looks away. Pass the phone face down."}
                </Txt>
                <Button
                  kind="secondary"
                  onPress={() => {
                    if (!secretVisible) setSecretVisible(true);
                    else {
                      setSecretVisible(false);
                      action({ type: "HIDE_PRIVATE_REVEAL" });
                    }
                  }}
                >
                  {secretVisible ? "Hide & pass" : "Reveal my role"}
                </Button>
                {!secretVisible && (
                  <Button
                    kind="ghost"
                    onPress={() => {
                      setSecretVisible(false);
                      void safely(async () => {
                        await changeSession(id, (session) =>
                          passPartyTurn(
                            session,
                            r.secrets[r.revealIndex].playerId,
                          ),
                        );
                        await advanceParty(id, { skip: true });
                      });
                    }}
                  >
                    Pass this role
                  </Button>
                )}
              </View>
            ) : undefined
          }
        >
          {r.status !== "private_reveal" &&
            (needsPlayers ? (
              <View style={{ gap: 12 }}>
                <Txt>Someone passed. No pressure.</Txt>
                <Button
                  kind="secondary"
                  onPress={() => advance({ skip: true })}
                >
                  Choose new players
                </Button>
              </View>
            ) : paused ? (
              <Button
                icon="play"
                disabled={busy}
                onPress={() => action({ type: "RESUME" })}
              >
                Resume
              </Button>
            ) : r.status === "intro" || r.status === "ready" ? (
              <Button icon="play" disabled={busy} onPress={start}>
                {r.secrets.length && r.status === "intro"
                  ? "Pass out the roles"
                  : "Start"}
              </Button>
            ) : null)}
        </PartyDeckCard>
      )}
      {allowed &&
        live &&
        !needsPlayers &&
        card.pattern === "TURN_BASED" &&
        turnPlayer && (
          <Card style={{ padding: 16, gap: 8 }}>
            <Txt weight="bold">
              {turnPlayer.displayName}, you’re up
              {a.id === "W4"
                ? ` · ${r.turn % 2 === 0 ? "Fortunately…" : "Unfortunately…"}`
                : a.id === "W1"
                  ? " · Yes, and…"
                  : ""}
            </Txt>
            <Row>
              <Button
                small
                kind="secondary"
                onPress={() =>
                  void safely(() =>
                    changeSession(id, (session) =>
                      nextPartyTurn(session, uuid, new Date().toISOString()),
                    ),
                  )
                }
              >
                Next turn
              </Button>
              <Button
                small
                kind="ghost"
                onPress={() =>
                  void safely(() =>
                    changeSession(id, (session) =>
                      passPartyTurn(session, turnPlayer.id),
                    ),
                  )
                }
              >
                Pass turn
              </Button>
            </Row>
            <Txt muted size={12}>
              Optional guide. You can also just go around the group.
            </Txt>
          </Card>
        )}
      {largeDisplay && (
        <Button small kind="secondary" onPress={() => setLargeDisplay(false)}>
          Exit Large Display
        </Button>
      )}
      {toast && (
        <Txt
          size={14}
          accessibilityLiveRegion="polite"
          style={{ color: t.accentInk }}
        >
          {toast}
        </Txt>
      )}
      <Dialog
        visible={sheet !== null}
        onClose={() => setSheet(null)}
        title={
          sheet
            ? {
                more: "Your party",
                rules: "How to Play",
                players: "Your people",
                preferences: "Party preferences",
                games: "Choose a party game",
                feedback: "How did it land?",
              }[sheet]
            : "Your party"
        }
      >
        {sheet === "more" && (
          <>
            {live && (
              <Button
                kind="secondary"
                icon="pause"
                onPress={() =>
                  void safely(async () => {
                    await act(id, { type: "PAUSE" });
                    setSheet(null);
                  })
                }
              >
                Pause
              </Button>
            )}
            {allowed && (
              <>
                <Button
                  kind="secondary"
                  icon="heart"
                  onPress={() => favorite(a.id)}
                >
                  {data.favorites.includes(a.id)
                    ? "Unfavorite Game"
                    : "Favorite Game"}
                </Button>
              </>
            )}
            <Button kind="secondary" onPress={() => advance({ replay: true })}>
              Replay Card
            </Button>
            <Button kind="secondary" onPress={() => setSheet("games")}>
              Choose a game
            </Button>
            {recipe && recipe.durationSec > 0 && (
              <>
                <Toggle
                  label="Scene timer"
                  sub="Optional. Finishing the timer never changes the card."
                  value={r.remainingMs > 0}
                  onChange={(enabled) =>
                    void safely(() =>
                      changeSession(id, (session) => ({
                        ...session,
                        rounds: session.rounds.map((round) =>
                          round.id === r.id
                            ? {
                                ...round,
                                remainingMs: enabled
                                  ? recipe.durationSec * 1000
                                  : 0,
                              }
                            : round,
                        ),
                      })),
                    )
                  }
                />
                <Button
                  kind="secondary"
                  onPress={() =>
                    void safely(() =>
                      changeSession(id, (session) => ({
                        ...session,
                        rounds: session.rounds.map((round) =>
                          round.id === r.id
                            ? {
                                ...round,
                                remainingMs: recipe.durationSec * 1000,
                              }
                            : round,
                        ),
                      })),
                    )
                  }
                >
                  Restart timer
                </Button>
              </>
            )}
            {allowed &&
              (Object.keys(r.promptSnapshot.entries).length > 0 ||
                r.promptSnapshot.jokeTopic) && (
                <Button kind="secondary" onPress={save}>
                  Save Prompt
                </Button>
              )}
            <Button
              kind="secondary"
              onPress={() => {
                setLargeDisplay(!largeDisplay);
                setSheet(null);
              }}
            >
              {largeDisplay ? "Exit Large Display" : "Large Display"}
            </Button>
            <Button kind="secondary" onPress={() => open("players")}>
              Players & passes
            </Button>
            <Button kind="secondary" onPress={() => open("preferences")}>
              Party preferences
            </Button>
            <Button kind="secondary" onPress={() => setSheet("feedback")}>
              Rate this card
            </Button>
            <Button
              kind="secondary"
              onPress={() =>
                void safely(async () => {
                  await act(id, { type: "PAUSE" });
                  router.replace("/");
                })
              }
            >
              Save & leave
            </Button>
            <Button kind="ghost" onPress={end}>
              End Session
            </Button>
          </>
        )}
        {sheet === "rules" && (
          <>
            <Txt weight="bold">{a.title}</Txt>
            <Txt>{a.howTo}</Txt>
            <Eyebrow>TRY IT LIKE THIS</Eyebrow>
            <Txt>{bookFor(a).example}</Txt>
            <Txt muted>Pass freely. Nobody owes the group a performance.</Txt>
          </>
        )}
        {sheet === "players" && (
          <>
            <Txt muted size={14}>
              Pass freely, sit out, or change the group. Earlier cards keep
              their original assignments.
            </Txt>
            {editingPlayers ? (
              <>
                {roster.map((p, i) => (
                  <View key={p.id ?? `new-${i}`} style={{ gap: 4 }}>
                    <Field
                      label={`Player ${i + 1} name`}
                      value={p.name}
                      placeholder={`Player ${i + 1}`}
                      onChangeText={(name) =>
                        setRoster((old) =>
                          old.map((p, j) =>
                            i === j ? { ...p, name: name.slice(0, 40) } : p,
                          ),
                        )
                      }
                    />
                    <Button
                      small
                      kind="ghost"
                      disabled={roster.length <= 2}
                      onPress={() =>
                        setRoster((old) => old.filter((_, j) => i !== j))
                      }
                    >
                      Remove player {i + 1}
                    </Button>
                  </View>
                ))}
                <Button
                  kind="secondary"
                  disabled={roster.length >= 12}
                  onPress={() => setRoster((old) => [...old, { name: "" }])}
                >
                  Add player
                </Button>
                <Txt muted size={13}>
                  Adding or removing people deals a fresh Clean card. Adult
                  cards need confirmation for the new group.
                </Txt>
                <Button
                  disabled={busy}
                  onPress={() =>
                    void safely(async () => {
                      await editPartyPlayers(id, roster);
                      setSheet(null);
                      setToast("Group updated.");
                    })
                  }
                >
                  Save players
                </Button>
                <Button kind="ghost" onPress={() => setEditingPlayers(false)}>
                  Cancel edits
                </Button>
              </>
            ) : (
              <>
                <Button
                  kind="secondary"
                  onPress={() => setEditingPlayers(true)}
                >
                  Edit names, add or remove players
                </Button>
                {s.players.map((p) => (
                  <View key={p.id} style={{ gap: 5 }}>
                    <Txt weight="bold">{p.displayName}</Txt>
                    <Row>
                      <Button
                        small
                        kind="secondary"
                        disabled={
                          p.isSittingOut ||
                          s.party!.passedPlayerIds.includes(p.id)
                        }
                        onPress={() =>
                          void safely(() =>
                            changeSession(id, (session) =>
                              passPartyTurn(session, p.id),
                            ),
                          )
                        }
                      >
                        Pass {p.displayName}
                      </Button>
                      <Button
                        small
                        kind="ghost"
                        onPress={() =>
                          void safely(() =>
                            changeSession(id, (session) =>
                              setPartySittingOut(
                                session,
                                p.id,
                                !p.isSittingOut,
                              ),
                            ),
                          )
                        }
                      >
                        {p.isSittingOut
                          ? `Rejoin ${p.displayName}`
                          : `Sit out ${p.displayName}`}
                      </Button>
                    </Row>
                  </View>
                ))}
                {s.party.passedPlayerIds.length > 0 && (
                  <Button
                    kind="secondary"
                    onPress={() =>
                      void safely(() =>
                        changeSession(id, (session) => ({
                          ...session,
                          party: { ...session.party!, passedPlayerIds: [] },
                        })),
                      )
                    }
                  >
                    Clear passes for the next card
                  </Button>
                )}
                {s.party.options.teams && (
                  <>
                    <Eyebrow>TEAMS · NO SCORING REQUIRED</Eyebrow>
                    {s.teams.map((team) => (
                      <View key={team.id} style={{ gap: 6 }}>
                        <Field
                          label={`Name for ${team.displayName}`}
                          value={team.displayName}
                          onChangeText={(displayName) =>
                            void changeSession(id, (session) => ({
                              ...session,
                              teams: session.teams.map((t) =>
                                t.id === team.id
                                  ? {
                                      ...t,
                                      displayName:
                                        displayName.trim().slice(0, 40) ||
                                        "Team",
                                    }
                                  : t,
                              ),
                            }))
                          }
                        />
                        <Txt size={14}>
                          {team.playerIds.map(name).join(", ")}
                        </Txt>
                        {team.playerIds.map((pid) => (
                          <Button
                            key={pid}
                            small
                            kind="ghost"
                            disabled={team.playerIds.length <= 1}
                            onPress={() =>
                              void safely(() =>
                                changeSession(id, (session) => ({
                                  ...session,
                                  teams: session.teams.map((t) => ({
                                    ...t,
                                    playerIds:
                                      t.id === team.id
                                        ? t.playerIds.filter((p) => p !== pid)
                                        : [...t.playerIds, pid],
                                  })),
                                })),
                              )
                            }
                          >
                            Move {name(pid)} to other team
                          </Button>
                        ))}
                      </View>
                    ))}
                  </>
                )}
                <Button onPress={() => setSheet(null)}>Done</Button>
              </>
            )}
          </>
        )}
        {sheet === "preferences" && (
          <>
            {draft && (
              <PartyOptionsFields
                value={draft}
                onChange={setDraft}
                classroom={data.preferences.classroomDefault}
              />
            )}
            <Button
              disabled={
                !draft ||
                (draft.level === "18_plus" && !draft.adultsConfirmedAt)
              }
              onPress={() =>
                void safely(async () => {
                  if (!draft) return;
                  const options = normalizePartyOptions(
                    draft,
                    data.preferences.classroomDefault,
                  );
                  await changeSession(id, (session) => {
                    if (options.teams && !session.teams.length)
                      session = editPartyRoster(
                        session,
                        session.players.map((p) => ({
                          id: p.id,
                          name: p.displayName,
                        })),
                        uuid,
                        new Date().toISOString(),
                      );
                    const changed = {
                      ...session,
                      settings: {
                        ...session.settings,
                        cuePreference: options.automaticCues
                          ? ("sound_and_visual" as const)
                          : ("manual" as const),
                      },
                      party: { ...session.party!, options },
                    };
                    return partyCardAllowed(
                      changed,
                      data.preferences.classroomDefault,
                    )
                      ? changed
                      : appendPartyCard(
                          changed,
                          uuid,
                          new Date().toISOString(),
                          {
                            skip: true,
                          },
                        );
                  });
                  setSheet(null);
                  setToast(`Playing ${levelLabel(options.level)}.`);
                })
              }
            >
              Apply preferences
            </Button>
            {s.party.options.level !== "clean" && (
              <Button
                kind="secondary"
                onPress={() =>
                  void safely(async () => {
                    await changeSession(id, (session) => {
                      const clean = {
                        ...session,
                        party: {
                          ...session.party!,
                          options: {
                            ...session.party!.options,
                            level: "clean" as const,
                            adultsConfirmedAt: null,
                          },
                        },
                      };
                      return partyCardAllowed(clean, true)
                        ? clean
                        : appendPartyCard(
                            clean,
                            uuid,
                            new Date().toISOString(),
                            {
                              skip: true,
                            },
                          );
                    });
                    setSheet(null);
                    setToast("Playing Clean.");
                  })
                }
              >
                Return to Clean
              </Button>
            )}
          </>
        )}
        {sheet === "games" && (
          <>
            <Txt muted size={14}>
              Keep this group. We’ll deal a compatible card for your chosen
              game.
            </Txt>
            {compatiblePartyRecipes(s)
              .filter(
                (recipe, i, all) =>
                  !all
                    .slice(i + 1)
                    .some((r) => r.activityId === recipe.activityId),
              )
              .map((recipe) => (
                <Button
                  key={recipe.id}
                  kind="secondary"
                  onPress={() => advance({ recipeId: recipe.id })}
                >
                  {activityById(recipe.activityId).title}
                </Button>
              ))}
          </>
        )}
        {sheet === "feedback" && (
          <FeedbackChoices
            disabled={busy}
            onRate={(rating) =>
              void safely(async () => {
                await update((d) => ({
                  ...d,
                  feedback: [
                    ...d.feedback,
                    {
                      id: uuid(),
                      activityId: a.id,
                      roundId: r.id,
                      recipeId: card.recipeId,
                      rating,
                      createdAt: new Date().toISOString(),
                    },
                  ],
                }));
                setToast("Feedback saved on this device.");
                setSheet(null);
              })
            }
          />
        )}
      </Dialog>
    </Page>
  );
}
