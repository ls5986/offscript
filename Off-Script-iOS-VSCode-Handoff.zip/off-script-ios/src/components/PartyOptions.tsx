import { View } from "react-native";
import { Chip, Disclosure, Eyebrow, Row, Toggle, Txt } from "../design/ui";
import type {
  PartyOptions as Options,
  PartyLevel,
} from "../domain/party-contracts";
export const levelLabel = (level: PartyLevel) =>
  level === "18_plus" ? "18+" : level === "spicy" ? "Spicy" : "Clean";
export function PartyOptionsFields({
  value,
  onChange,
  classroom,
}: {
  value: Options;
  onChange: (v: Options) => void;
  classroom: boolean;
}) {
  const change = (v: Partial<Options>) => onChange({ ...value, ...v });
  return (
    <View style={{ gap: 12 }}>
      <Eyebrow>THE MATERIAL</Eyebrow>
      <Row>
        {(["clean", "spicy", "18_plus"] as const).map((level) => (
          <Chip
            key={level}
            selected={value.level === level}
            onPress={() => {
              if (!classroom || level === "clean")
                change({ level, adultsConfirmedAt: null });
            }}
          >
            {levelLabel(level)}
          </Chip>
        ))}
      </Row>
      <Txt muted size={14}>
        {classroom
          ? "Classroom clean is on. All cards stay Clean; change this in Settings."
          : value.level === "clean"
            ? "Everyday absurdity. Suitable for mixed groups."
            : value.level === "spicy"
              ? "Dating disasters, flirting, and cheeky innuendo. Pass freely."
              : "Suggestive adult comedy, including Sex With Me Is Like. No dares or personal disclosures."}
      </Txt>
      {value.level === "18_plus" && !classroom && (
        <Toggle
          label="Everyone is 18+ and wants adult cards"
          sub="Confirm for this group. Anyone can pass or return to Clean."
          value={!!value.adultsConfirmedAt}
          onChange={(confirmed) =>
            change({
              adultsConfirmedAt: confirmed ? new Date().toISOString() : null,
            })
          }
        />
      )}
      <Toggle
        label="Mix in short scenes"
        sub="A few pair and scene cards between quick games. Turn off for an entirely untimed deck."
        value={value.includeScenes}
        onChange={(includeScenes) => change({ includeScenes })}
      />
      <Toggle
        label="Team turns"
        sub="Teams alternate on joke and open-mic cards. No scoring required."
        value={value.teams}
        onChange={(teams) => change({ teams })}
      />
      <Disclosure title="Pacing, movement & cues">
        <Eyebrow>PACING</Eyebrow>
        <Row>
          {(["quick", "balanced", "relaxed"] as const).map((pacing) => (
            <Chip
              key={pacing}
              selected={value.pacing === pacing}
              onPress={() => change({ pacing })}
            >
              {pacing === "quick"
                ? "Quick laughs"
                : pacing === "balanced"
                  ? "A little of everything"
                  : "Room for scenes"}
            </Chip>
          ))}
        </Row>
        <Toggle
          label="Include movement games"
          sub="Off by default. No contact required."
          value={value.movement}
          onChange={(movement) => change({ movement })}
        />
        <Toggle
          label="Automatic visual cues"
          sub="New Choice and remote games. Manual buttons always work."
          value={value.automaticCues}
          onChange={(automaticCues) => change({ automaticCues })}
        />
        <Toggle
          label="Speak cues aloud"
          sub="Optional. Your device may silence speech; watch the visual cue."
          value={value.sound}
          onChange={(sound) => change({ sound })}
        />
      </Disclosure>
    </View>
  );
}
