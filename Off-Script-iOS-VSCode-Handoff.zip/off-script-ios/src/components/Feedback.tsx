import { useState } from "react";
import { Button, Chip, Dialog, Row, Txt } from "../design/ui";
import type { PromptSnapshot } from "../domain/contracts";
import { useApp, uuid } from "../providers/AppProvider";
import type { AppData } from "../storage/model";
type Rating = AppData["feedback"][number]["rating"];
export function FeedbackChoices({
  onRate,
  disabled = false,
}: {
  onRate: (rating: Rating) => void;
  disabled?: boolean;
}) {
  return (
    <>
      <Txt muted size={14}>
        Feedback stays on this device. It is not sent anywhere.
      </Txt>
      <Row>
        {(
          [
            ["fun", "Made us laugh"],
            ["easy", "Easy to play"],
            ["too_hard", "Too much work"],
            ["not_for_us", "Not for us"],
          ] as const
        ).map(([rating, label]) => (
          <Chip key={rating} disabled={disabled} onPress={() => onRate(rating)}>
            {label}
          </Chip>
        ))}
      </Row>
    </>
  );
}
export function Feedback({
  activityId,
  roundId,
  snapshot,
}: {
  activityId: string;
  roundId: string;
  snapshot?: PromptSnapshot;
}) {
  const { update } = useApp();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const rate = async (rating: Rating) => {
    if (busy) return;
    setBusy(true);
    try {
      await update((d) => ({
        ...d,
        feedback: [
          ...d.feedback,
          {
            id: uuid(),
            activityId,
            roundId,
            targetType: snapshot ? "prompt" : "activity",
            snapshot: snapshot ? structuredClone(snapshot) : undefined,
            rating,
            createdAt: new Date().toISOString(),
          },
        ],
      }));
      setMessage("Feedback saved on this device.");
      setOpen(false);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Could not save feedback.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <Button small kind="ghost" onPress={() => setOpen(true)}>
        {snapshot ? "Rate this prompt" : "Rate this game"}
      </Button>
      {message && (
        <Txt size={13} accessibilityLiveRegion="polite">
          {message}
        </Txt>
      )}
      <Dialog
        visible={open}
        onClose={() => setOpen(false)}
        title="How did it land?"
      >
        <FeedbackChoices disabled={busy} onRate={(r) => void rate(r)} />
      </Dialog>
    </>
  );
}
