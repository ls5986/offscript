import type { ReactNode } from "react";
import { View, useWindowDimensions } from "react-native";
import { Card, Eyebrow, Txt, useTheme } from "../design/ui";
import { composeScene } from "../domain/composer";
import { activityById, categoryLabels } from "../domain/content";
import { partyParticipantText, partyPromptText } from "../domain/party";
import { partyInstruction } from "../domain/playbooks";
import {
  currentRound,
  rapidOpening,
  type SessionSnapshot,
} from "../domain/session";
/** One readable, self-contained card. Mechanics and persistence stay in the shared engines. */
export function PartyDeckCard({
  session,
  privateContent,
  children,
  large = false,
}: {
  session: SessionSnapshot;
  privateContent?: ReactNode;
  children?: ReactNode;
  large?: boolean;
}) {
  const t = useTheme();
  const { width, height } = useWindowDimensions();
  const compact = height < 650;
  const r = currentRound(session);
  const a = activityById(r.activityId);
  const remaining = composeScene(r.promptSnapshot)?.remainingCategories ?? [];
  const color = [t.lilac, t.blue, t.sage][r.ordinal % 3];
  return (
    <View style={{ paddingBottom: 8, paddingRight: 5 }}>
      <View
        pointerEvents="none"
        style={{
          position: "absolute",
          top: 13,
          bottom: 0,
          left: 8,
          right: 0,
          borderRadius: 24,
          backgroundColor: t.line,
          transform: [{ rotate: "1deg" }],
        }}
      />
      <Card
        style={{
          backgroundColor: color,
          minHeight: compact ? 300 : 370,
          padding: compact ? 22 : 28,
          gap: compact ? 16 : 22,
          justifyContent: "center",
        }}
      >
        {privateContent ?? (
          <>
            <View
              style={{
                alignSelf: "flex-start",
                borderRadius: 20,
                backgroundColor: t.card,
                paddingHorizontal: 13,
                paddingVertical: 7,
              }}
            >
              <Txt weight="bold" size={13}>
                {partyParticipantText(session)}
              </Txt>
            </View>
            <Eyebrow>{a.title}</Eyebrow>
            <Txt
              testID="party-prompt"
              serif
              size={
                large
                  ? 52
                  : width < 360
                    ? 27
                    : r.promptSnapshot.jokeTopic
                      ? 42
                      : 32
              }
              style={{
                lineHeight: large
                  ? 64
                  : width < 360
                    ? 35
                    : r.promptSnapshot.jokeTopic
                      ? 51
                      : 41,
              }}
            >
              {partyPromptText(r)}
            </Txt>
            {remaining.map((category) => (
              <Txt key={category} size={large ? 24 : 17}>
                <Txt weight="bold">{categoryLabels[category]}: </Txt>
                {r.promptSnapshot.entries[category].text}
              </Txt>
            ))}
            <Txt size={large ? 25 : compact ? 16 : 18}>
              {partyInstruction(a)}
            </Txt>
            {a.id === "G11" && (
              <Txt size={large ? 22 : 14}>
                Presenter:{" "}
                {
                  session.players.find((p) => p.id === r.performerIds[0])
                    ?.displayName
                }{" "}
                · Inventors:{" "}
                {r.performerIds
                  .slice(1)
                  .map(
                    (pid) =>
                      session.players.find((p) => p.id === pid)?.displayName,
                  )
                  .join(" + ")}
              </Txt>
            )}
            {a.id === "P3" && (
              <Txt size={14} muted>
                {rapidOpening(r)}
              </Txt>
            )}
            {r.supportingPlayerIds.length > 0 && (
              <Txt size={14}>
                Expert:{" "}
                {
                  session.players.find((p) => p.id === r.performerIds[0])
                    ?.displayName
                }{" "}
                · Interviewer:{" "}
                {r.supportingPlayerIds
                  .map(
                    (pid) =>
                      session.players.find((p) => p.id === pid)?.displayName,
                  )
                  .join(", ")}
              </Txt>
            )}
          </>
        )}
        {children}
      </Card>
    </View>
  );
}
