import { PartyStateSchema } from "./party-contracts";
import { refreshComposition } from "./composer";
import { z } from "zod";
import {
  activities,
  activityById,
  goals,
  PACK,
  prompts,
  quirks,
  TimedCue,
  TimedCueSchema,
  topics,
} from "./content";
import {
  Activity,
  Player,
  PlayerSchema,
  PromptSnapshot,
  RoundStateSchema,
  ScoreAwardSchema,
  SessionSettings,
  SessionSettingsSchema,
  TeamSchema,
  UserPreferences,
  VoteSchema,
} from "./contracts";
import { isRiffPick, riffCategories, type PlayIntent } from "./playbooks";
import { emptyPrompt, generatePrompt } from "./prompts";
import { RNG, sample, seededRng, weighted } from "./random";
export const SecretSchema = z.object({
  playerId: z.string().uuid(),
  id: z.string(),
  text: z.string(),
  guessed: z.boolean(),
});
export const GameRoundSchema = RoundStateSchema.extend({
  rngCursor: z.number().int().nonnegative(),
  segment: z.number().int().min(0).max(3),
  segmentReady: z.boolean(),
  elapsedMs: z.number().nonnegative(),
  turn: z.number().int().nonnegative(),
  variant: z.enum(["take_turns", "open_mic", "battle"]),
  cue: TimedCueSchema.nullable(),
  secrets: z.array(SecretSchema),
  revealIndex: z.number().int().nonnegative(),
  schedule: z.array(TimedCueSchema),
  participation: z
    .record(
      z.string(),
      z.object({
        performanceMs: z.number().nonnegative(),
        supportMs: z.number().nonnegative(),
      }),
    )
    .default({}),
});
export type GameRound = z.infer<typeof GameRoundSchema>;
export const SessionSnapshotSchema = z.object({
  id: z.string().uuid(),
  settings: SessionSettingsSchema,
  party: PartyStateSchema.optional(),
  players: z.array(PlayerSchema),
  rounds: z.array(GameRoundSchema),
  status: z.enum(["active", "paused", "finished"]),
  seed: z.number().int().nonnegative(),
  contentPackVersion: z.string(),
  createdAt: z.string(),
  updatedAt: z.string(),
  scores: z.array(ScoreAwardSchema),
  teams: z.array(TeamSchema),
  votes: z.array(VoteSchema),
  note: z.string().max(500),
});
export type SessionSnapshot = z.infer<typeof SessionSnapshotSchema>;
export type ID = () => string;
export const currentRound = (s: SessionSnapshot) =>
  s.rounds[s.rounds.length - 1];
export function eligibleActivities(
  settings: SessionSettings,
  prefs: UserPreferences,
  pool: Activity[] = activities,
): Activity[] {
  return pool.filter(
    (a) =>
      (settings.playFlow !== "free" || a.id !== "G10") &&
      a.minPlayers <= settings.playerCount &&
      a.maxPlayers >= settings.playerCount &&
      (settings.mode === "surprise" || a.modes.includes(settings.mode)) &&
      (a.contentRating === "clean" ||
        (prefs.matureOptIn &&
          !prefs.classroomDefault &&
          !settings.classroomClean &&
          settings.contentRating === "mature_suggestive")) &&
      (settings.energy !== "seated" ||
        a.energy === "seated" ||
        ["movement", "story_turn"].includes(a.engine) ||
        ["G5", "G7", "T3"].includes(a.id)) &&
      (!settings.excludeMovement || a.energy === "seated") &&
      a.promptCategories.every((c) =>
        prompts.some(
          (p) =>
            p.category === c &&
            p.minPlayers <=
              Math.max(2, Math.min(settings.playerCount, a.maxPerformers)) &&
            p.maxPlayers >=
              Math.max(2, Math.min(settings.playerCount, a.maxPerformers)),
        ),
      ),
  );
}
export function chooseNextActivity(
  settings: SessionSettings,
  prefs: UserPreferences,
  history: GameRound[],
  rng: RNG,
): Activity {
  const hardEligible = eligibleActivities(settings, prefs);
  const eligible =
    settings.playIntent === "riff" && settings.mode === "surprise"
      ? hardEligible.filter(isRiffPick)
      : hardEligible;
  if (!eligible.length)
    throw Error(
      "No games fit these settings. Try a different group size or experience.",
    );
  const last = history.at(-1);
  const recent = history.slice(-5).map((r) => r.activityId);
  const pool = eligible.filter((a) => !recent.includes(a.id));
  const candidates = pool.length
    ? pool
    : eligible.filter((a) => a.id !== last?.activityId);
  return weighted(
    candidates.length ? candidates : eligible,
    (a) => {
      let w = 1;
      if (settings.playIntent === "practice")
        w *=
          a.family === "scene" || a.family === "drill"
            ? 3
            : a.family === "punchline"
              ? 0.5
              : 1;
      if (last && a.family !== activityById(last.activityId).family) w *= 2;
      if (
        history.length < 3 &&
        ["story_turn", "rapid_fire", "scene_open"].includes(a.engine)
      )
        w *= 2;
      if (
        history.filter((r) => r.activityId === a.id && r.status === "skipped")
          .length
      )
        w *= 0.4;
      if (settings.playerCount === 2 && a.modes.includes("just_us")) w *= 1.4;
      if (a.energy === "seated") w *= 1.2;
      if (
        last &&
        activityById(last.activityId).defaultDurationSec < 90 !==
          a.defaultDurationSec < 90
      )
        w *= 1.5;
      return w;
    },
    rng,
  );
}
export function exposure(playerId: string, history: GameRound[]) {
  const played = history.filter(
    (r) =>
      r.startedAt &&
      (r.performerIds.includes(playerId) ||
        (r.participation[playerId]?.performanceMs ?? 0) > 0),
  );
  return {
    rounds: played.length,
    seconds: played.reduce(
      (s, r) =>
        s +
        (r.participation[playerId]?.performanceMs ??
          (r.performerIds.includes(playerId) ? r.elapsedMs : 0)) /
          1000,
      0,
    ),
    last: played.at(-1)?.ordinal ?? -1,
    support: history.filter(
      (r) =>
        r.startedAt &&
        (r.supportingPlayerIds.includes(playerId) ||
          (r.participation[playerId]?.supportMs ?? 0) > 0),
    ).length,
  };
}
export function assignPerformers(
  a: Activity,
  players: Player[],
  history: GameRound[],
  rng: RNG,
): { performerIds: string[]; supportingPlayerIds: string[] } {
  const active = players.filter((p) => !p.isSittingOut);
  const shuffle = active
    .map((p) => ({ p, tie: rng(), e: exposure(p.id, history) }))
    .sort(
      (a, b) =>
        a.e.rounds - b.e.rounds ||
        a.e.seconds - b.e.seconds ||
        a.e.last - b.e.last ||
        a.tie - b.tie,
    );
  let n = ["take_turns", "ensemble"].includes(a.playPattern)
    ? Math.min(active.length, a.maxPerformers)
    : a.minPerformers;
  if (a.id === "G7") n = 2;
  if (a.id === "T3") n = Math.min(active.length - 1, 5);
  const first = shuffle[0]?.p.id;
  if (n === 2 && shuffle.length > 2) {
    const min = shuffle[1].e.rounds;
    const candidates = shuffle.slice(1).filter((x) => x.e.rounds === min);
    candidates.sort(
      (x, y) =>
        history.filter(
          (r) =>
            r.startedAt &&
            r.performerIds.includes(first) &&
            r.performerIds.includes(x.p.id),
        ).length -
        history.filter(
          (r) =>
            r.startedAt &&
            r.performerIds.includes(first) &&
            r.performerIds.includes(y.p.id),
        ).length,
    );
    if (candidates.length) {
      const second = candidates[0];
      shuffle.splice(shuffle.indexOf(second), 1);
      shuffle.splice(1, 0, second);
    }
  }
  const performerIds = shuffle.slice(0, n).map((x) => x.p.id);
  let supportingPlayerIds: string[] = [];
  if (["G7", "T3", "G6", "G8"].includes(a.id)) {
    if (a.id === "G7" || a.id === "T3")
      supportingPlayerIds = shuffle.slice(n, n + 1).map((x) => x.p.id);
    else {
      supportingPlayerIds = performerIds.splice(1, 1);
    }
  }
  return { performerIds, supportingPlayerIds };
}
export function generateCueSchedule(
  a: Activity,
  rng: RNG,
  flavor: "playful" | "grounded" = "grounded",
): TimedCue[] {
  const type = a.cueTypes[0];
  if (!type || a.id === "G10") return [];
  const schedule: TimedCue[] = [];
  let last = "";
  for (
    let t = 20000;
    t < a.defaultDurationSec * 1000;
    t += 20000 + Math.floor(rng() * 12000)
  ) {
    let text =
      type === "new_choice"
        ? "NEW CHOICE!"
        : type === "rotation"
          ? "Relay: new player, same scene."
          : type === "status_shift"
            ? "Reverse who has the higher status."
            : type;
    if (["emotion_change", "genre_change", "surprise_line"].includes(type)) {
      const category =
        type === "emotion_change"
          ? "emotion"
          : type === "genre_change"
            ? "genre"
            : "opening_line";
      const compatible = prompts.filter(
        (p) => p.category === category && p.contentRating === "clean" && p.text !== last,
      );
      const flavored = compatible.filter((p) => p.flavor === flavor);
      text = sample(flavored.length ? flavored : compatible, rng).text;
    }
    last = text;
    schedule.push({
      id: `cue_${schedule.length}`,
      type,
      text,
      atElapsedMs: t,
      displayDurationMs: 6000,
      spokenText: text,
    });
  }
  return schedule;
}
export function prepareRound(
  s: SessionSnapshot,
  a: Activity,
  id: ID,
  now: string,
  prompt?: PromptSnapshot,
): GameRound {
  const ordinal = s.rounds.length;
  const rng = seededRng(s.seed + ordinal * 7919 + 17);
  const assignment = assignPerformers(a, s.players, s.rounds, rng);
  // Studio's ensemble variant keeps every authored role and seat assignment.
  if (prompt && a.id === "S1") {
    assignment.performerIds = s.players
      .filter((p) => !p.isSittingOut)
      .map((p) => p.id);
    assignment.supportingPlayerIds = [];
  }
  let snapshot =
    prompt ??
    generatePrompt(
      {
        categories:
          s.settings.playIntent === "riff"
            ? riffCategories(a)
            : a.promptCategories,
        flavor: s.settings.playIntent === "riff" ? "playful" : "grounded",
        count:
          assignment.performerIds.length < 2
            ? 2
            : assignment.performerIds.length,
        style: "coherent",
        playerIds: assignment.performerIds,
      },
      rng,
    ).snapshot;
  if (a.engine === "rapid_fire") {
    const word = sample(
      topics.filter(
        (t) => t.id !== currentRound(s)?.promptSnapshot.jokeTopic?.id,
      ),
      rng,
    );
    snapshot = {
      ...(a.id === "P4" || a.id === "P5" || a.id === "P6"
        ? snapshot
        : emptyPrompt()),
      jokeTopic: { id: word.id, word: word.word },
    };
  }
  const secretPool = a.id === "T3" ? quirks : goals;
  const available = [...secretPool];
  const secrets = a.requiresPrivateReveal
    ? assignment.performerIds.map((playerId) => {
        const entry = sample(available, rng);
        available.splice(available.indexOf(entry), 1);
        return { playerId, id: entry.id, text: entry.text, guessed: false };
      })
    : [];
  return {
    id: id(),
    sessionId: s.id,
    ordinal,
    activityId: a.id,
    status: "intro",
    ...assignment,
    promptSnapshot: snapshot,
    remainingMs:
      s.settings.playFlow === "free"
        ? 0
        : a.id === "G10"
          ? 60000
          : (s.settings.playIntent === "riff"
              ? Math.min(90, a.defaultDurationSec)
              : a.defaultDurationSec) * 1000,
    timerStartedAtEpochMs: null,
    cueIndex: 0,
    startedAt: null,
    completedAt: null,
    rngCursor: 0,
    segment: 0,
    segmentReady: false,
    elapsedMs: 0,
    turn: 0,
    variant: "take_turns",
    cue: null,
    secrets,
    revealIndex: 0,
    participation: {},
    schedule:
      s.settings.playFlow === "free"
        ? []
        : generateCueSchedule(
            a,
            rng,
            s.settings.playIntent === "riff" ? "playful" : "grounded",
          ),
  };
}
export function makeSession(
  count: number,
  mode: SessionSettings["mode"],
  prefs: UserPreferences,
  id: ID,
  seed: number,
  names: string[] = [],
  activityId?: string,
  prompt?: PromptSnapshot,
  playIntent?: PlayIntent,
  playFlow: SessionSettings["playFlow"] = "rounds",
): SessionSnapshot {
  const settings = SessionSettingsSchema.parse({
    mode,
    playIntent:
      playIntent ??
      (mode === "scene_lab" || mode === "improv_gym"
        ? "practice"
        : prefs.playIntent),
    playerCount: count,
    playFlow,
    cuePreference: playFlow === "free" ? "manual" : "sound_and_visual",
    namesOptional: !names.some((name) => name.trim()),
    rngSeed: seed,
    classroomClean: prefs.classroomDefault,
    contentRating:
      prefs.matureOptIn && !prefs.classroomDefault
        ? "mature_suggestive"
        : "clean",
  });
  const now = new Date().toISOString();
  const s: SessionSnapshot = {
    id: id(),
    settings,
    seed,
    players: Array.from({ length: count }, (_, i) => ({
      id: id(),
      displayName: names[i]?.trim().slice(0, 40) || `Player ${i + 1}`,
      seatIndex: i,
      isSittingOut: false,
    })),
    rounds: [],
    status: "active",
    contentPackVersion: PACK,
    createdAt: now,
    updatedAt: now,
    scores: [],
    teams: [],
    votes: [],
    note: "",
  };
  s.teams = [
    {
      id: id(),
      sessionId: s.id,
      displayName: "Team A",
      playerIds: s.players.filter((_, i) => i % 2 === 0).map((p) => p.id),
    },
    {
      id: id(),
      sessionId: s.id,
      displayName: "Team B",
      playerIds: s.players.filter((_, i) => i % 2 === 1).map((p) => p.id),
    },
  ];
  const a = activityId
    ? activityById(activityId)
    : chooseNextActivity(settings, prefs, [], seededRng(seed));
  if (
    !eligibleActivities({ ...settings, mode: "surprise" }, prefs).some(
      (x) => x.id === a.id,
    )
  )
    throw Error(
      "This game is not available for this group or content setting.",
    );
  s.rounds.push(prepareRound(s, a, id, now, prompt));
  return s;
}
export type GameAction =
  | {
      type:
        | "READY"
        | "START"
        | "PAUSE"
        | "RESUME"
        | "FINISH"
        | "SKIP"
        | "COMPLETE"
        | "HIDE_PRIVATE_REVEAL"
        | "NEXT_TURN"
        | "NEXT_SEGMENT"
        | "CALL_CUE"
        | "ROTATE"
        | "REROLL_PROMPT";
    }
  | { type: "TICK"; deltaMs: number }
  | { type: "VARIANT"; variant: GameRound["variant"] }
  | { type: "MARK_GUESS"; playerId: string };
export function transitionRound(
  round: GameRound,
  action: GameAction,
  ctx: { now: string; rng: RNG; id: ID; session: SessionSnapshot },
): GameRound {
  let r = structuredClone(round);
  const a = activityById(r.activityId);
  const live = r.status === "live";
  if (["REROLL_PROMPT", "CALL_CUE", "ROTATE"].includes(action.type))
    r.rngCursor++;
  switch (action.type) {
    case "READY":
      if (r.status === "intro")
        r.status = r.secrets.length ? "private_reveal" : "ready";
      break;
    case "HIDE_PRIVATE_REVEAL":
      if (r.status === "private_reveal") {
        r.revealIndex++;
        if (r.revealIndex >= r.secrets.length) r.status = "ready";
      }
      break;
    case "START":
    case "RESUME":
      if (r.status === "ready" || r.status === "paused") {
        r.status = "live";
        r.startedAt ??= ctx.now;
      }
      break;
    case "PAUSE":
      if (live) r.status = "paused";
      break;
    case "FINISH":
      if (live || r.status === "paused") {
        r.status = "review";
        r.completedAt = ctx.now;
      }
      break;
    case "COMPLETE":
      if (r.status === "review") r.status = "complete";
      break;
    case "SKIP":
      if (!["complete", "skipped"].includes(r.status)) {
        r.status = "skipped";
        r.completedAt = ctx.now;
      }
      break;
    case "VARIANT":
      if (!live) r.variant = action.variant;
      break;
    case "MARK_GUESS":
      if (live || r.status === "review")
        r.secrets = r.secrets.map((s) =>
          s.playerId === action.playerId ? { ...s, guessed: !s.guessed } : s,
        );
      break;
    case "NEXT_TURN":
      if (live) r.turn++;
      break;
    case "ROTATE":
      if (live) {
        const waiting = ctx.session.players.filter(
          (p) => !p.isSittingOut && !r.performerIds.includes(p.id),
        );
        if (waiting.length) {
          const incoming = assignPerformers(
            {
              ...a,
              minPerformers: 1,
              maxPerformers: 1,
              playPattern: "volunteer",
            },
            waiting,
            ctx.session.rounds,
            ctx.rng,
          ).performerIds[0];
          r.performerIds = [...r.performerIds.slice(1), incoming];
        }
        r.turn++;
        r.cue = {
          id: ctx.id(),
          type: "rotation",
          text:
            a.id === "G5"
              ? "Freeze! Keep the pose. Start a completely NEW scene."
              : "New performer. Continue the SAME scene.",
          atElapsedMs: r.elapsedMs,
          displayDurationMs: 8000,
        };
      }
      break;
    case "NEXT_SEGMENT":
      if (live && a.id === "G10") {
        if (r.segmentReady) {
          r.segmentReady = false;
          r.remainingMs = [60000, 30000, 15000, 5000][r.segment];
        } else if (r.segment < 3) {
          r.segment++;
          r.segmentReady = true;
          r.remainingMs = [60000, 30000, 15000, 5000][r.segment];
        } else {
          r.status = "review";
          r.completedAt = ctx.now;
        }
      }
      break;
    case "CALL_CUE":
      if (live) {
        const type = a.cueTypes[0];
        if (type) {
          const schedule = generateCueSchedule(
            a,
            ctx.rng,
            ctx.session.settings.playIntent === "riff" ? "playful" : "grounded",
          );
          const pool = schedule.filter((c) => c.text !== r.cue?.text);
          const cue = sample(
            pool.length
              ? pool
              : schedule.length
                ? schedule
                : [
                    {
                      id: "manual",
                      type,
                      text: "Keep going",
                      atElapsedMs: 0,
                      displayDurationMs: 6000,
                    },
                  ],
            ctx.rng,
          );
          r.cue = { ...cue, id: ctx.id(), atElapsedMs: r.elapsedMs };
          r.cueIndex++;
        }
      }
      break;
    case "REROLL_PROMPT":
      if (
        !["private_reveal", "review", "complete", "skipped"].includes(
          r.status,
        ) &&
        !r.secrets.length
      ) {
        if (a.engine === "rapid_fire" && ["P1", "P2", "P3"].includes(a.id)) {
          const t = sample(
            topics.filter((t) => t.id !== r.promptSnapshot.jokeTopic?.id),
            ctx.rng,
          );
          r.promptSnapshot.jokeTopic = { id: t.id, word: t.word };
        } else
          r.promptSnapshot = generatePrompt(
            {
              categories:
                ctx.session.settings.playIntent === "riff"
                  ? riffCategories(a)
                  : a.promptCategories,
              flavor:
                ctx.session.settings.playIntent === "riff"
                  ? "playful"
                  : "grounded",
              count: Math.max(2, r.performerIds.length),
              style: "coherent",
              previous: r.promptSnapshot,
              playerIds: r.performerIds,
            },
            ctx.rng,
          ).snapshot;
      }
      if (ctx.session.settings.playFlow === "free" && a.id === "S6") r.turn = 0;
      break;
    case "TICK":
      if (live && !r.segmentReady) {
        const delta = Math.max(0, Math.round(Math.min(action.deltaMs, 2000)));
        r.elapsedMs += delta;
        for (const p of ctx.session.players) {
          const contribution = r.participation[p.id] ?? {
            performanceMs: 0,
            supportMs: 0,
          };
          if (r.performerIds.includes(p.id))
            contribution.performanceMs += delta;
          if (r.supportingPlayerIds.includes(p.id))
            contribution.supportMs += delta;
          r.participation[p.id] = contribution;
        }
        if (ctx.session.settings.playFlow === "free") break;
        r.remainingMs = Math.max(0, r.remainingMs - delta);
        // Hosted cue scenes keep issuing visual cues after their optional timer expires.
        if (ctx.session.party?.options.automaticCues &&
          ctx.session.party.cards.at(-1)?.pattern === "CUED_SCENE" &&
          !r.schedule.some(c => c.atElapsedMs > r.elapsedMs)) {
          const next = generateCueSchedule(a, ctx.rng, "playful")[0];
          if (next) r.schedule.push({ ...next, id: ctx.id(), atElapsedMs: r.elapsedMs + 20000 });
        }
        const due =
          ctx.session.settings.cuePreference === "manual"
            ? undefined
            : r.schedule.find(
                (c) =>
                  c.atElapsedMs > round.elapsedMs &&
                  c.atElapsedMs <= r.elapsedMs,
              );
        if (due) {
          r.cue = due;
          r.cueIndex++;
          if (due.type === "rotation") {
            const rotated = transitionRound(r, { type: "ROTATE" }, ctx);
            r.performerIds = rotated.performerIds;
            r.turn = rotated.turn;
          }
        }
        if (r.remainingMs === 0 && round.remainingMs > 0) {
          if (a.id === "G10") {
            if (r.segment < 3) {
              r.segment++;
              r.segmentReady = true;
              r.remainingMs = [60000, 30000, 15000, 5000][r.segment];
            } else {
              r.status = "review";
              r.completedAt = ctx.now;
            }
          } else
            r.cue = {
              id: ctx.id(),
              type: "stop",
              text: "Time! Find your ending — or keep playing.",
              atElapsedMs: r.elapsedMs,
              displayDurationMs: 10000,
            };
        }
      }
      break;
  }
  if (action.type === "REROLL_PROMPT")
    r.promptSnapshot = refreshComposition(r.promptSnapshot);
  return r;
}
export function restoreSession(s: SessionSnapshot): SessionSnapshot {
  const copy = SessionSnapshotSchema.parse(s);
  for (const r of copy.rounds) {
    if (r.status === "live") r.status = "paused";
    r.timerStartedAtEpochMs = null;
  }
  if (copy.status !== "finished") copy.status = "paused";
  return copy;
}
export const engineInstructions: Record<Activity["engine"], string> = {
  rapid_fire:
    "Use the opening below. Take a turn, pass freely, and keep it kind.",
  scene_open:
    "Start with a simple offer. Listen, accept the shared reality, and build together.",
  scene_cued:
    "Keep the scene going. Follow each visible cue without losing the story.",
  story_turn:
    "Pass the phone or take turns in seat order. Build one shared story.",
  movement:
    "No contact required. Stay seated if you like; small gestures work beautifully.",
  role_reveal:
    "Pass the phone privately. Only the named player looks at each secret.",
  interview:
    "One person asks or presents; the other responds in character. Commit to the idea.",
  hot_seat:
    "One character answers questions. Everyone else is curious, not trying to catch them out.",
  scene_rotation:
    "Waiting players join one at a time. Follow the replacement rule for this game.",
  short_challenge:
    "Only three lines: establish, respond, then add a clear change.",
};
export function rapidOpening(r: GameRound): string {
  const t = topics.find((t) => t.id === r.promptSnapshot.jokeTopic?.id);
  const w = t?.word ?? "candle";
  switch (r.activityId) {
    case "P1":
      return `Are you a ${w}? Because…`;
    case "P2":
      return `Sex with me is like a ${w} because…`;
    case "P3":
      return `185 ${t?.plural ?? "candles"} walk into a bar. The bartender says…`;
    case "P4":
      return `The world's worst ${r.promptSnapshot.entries.profession?.text.toLowerCase() ?? w} would…`;
    case "P5":
      return "You should definitely… (give intentionally terrible advice for this dilemma)";
    default:
      return "At this place, the one thing you should NEVER say is…";
  }
}
