import { z } from "zod";
import catalog from "../content/v1/activities.json";
import secretGoals from "../content/v1/goals.json";
import bank from "../content/v2/ingredients.json";
import partyIngredients from "../content/v2/party-ingredients.json";
import rels from "../content/v2/relationships.json";
import curated from "../content/v2/curated-scenes.json";
import guestQuirks from "../content/v1/quirks.json";
import words from "../content/v1/topics.json";
import {
  ActivitySchema,
  CueTypeSchema,
  JokeTopicSchema,
  PromptEntrySchema,
  RatingSchema,
  RelationshipTemplateSchema,
} from "./contracts";
export const SecretGoalSchema = z.object({
  id: z.string(),
  text: z.string().min(10),
  tags: z.array(z.string()),
  rating: RatingSchema,
  version: z.literal(1),
});
export const GuestQuirkSchema = SecretGoalSchema;
export const TimedCueSchema = z.object({
  id: z.string(),
  type: CueTypeSchema,
  text: z.string(),
  atElapsedMs: z.number().nonnegative(),
  displayDurationMs: z.number().positive(),
  spokenText: z.string().optional(),
});
export type TimedCue = z.infer<typeof TimedCueSchema>;
export const activities = z.array(ActivitySchema).parse(catalog);
export const prompts = z
  .array(PromptEntrySchema)
  .parse([...bank, ...partyIngredients]);
export const relationships = z.array(RelationshipTemplateSchema).parse(rels);
export const topics = z.array(JokeTopicSchema).parse(words);
export const goals = z.array(SecretGoalSchema).parse(secretGoals);
export const quirks = z.array(GuestQuirkSchema).parse(guestQuirks);
export const activityById = (id: string) => {
  const a = activities.find((x) => x.id === id);
  if (!a) throw Error("This game is not in the current content pack.");
  return a;
};
export const PACK = "2.3.0";
export const categories = [
  "relationship",
  "location",
  "profession",
  "role",
  "emotion",
  "action",
  "situation",
  "object",
  "genre",
  "opening_line",
] as const;
export type Category = (typeof categories)[number];
export const categoryLabels: Record<Category, string> = {
  relationship: "Relationship",
  location: "Location",
  profession: "Profession",
  role: "Character role",
  emotion: "Emotion",
  action: "Action",
  situation: "Situation",
  object: "Object",
  genre: "Genre",
  opening_line: "Opening line",
};
export const modes = [
  {
    id: "party_night",
    label: "Party Night",
    sub: "A little chaos. A lot of laughs.",
    icon: "party",
  },
  {
    id: "just_us",
    label: "Just Us",
    sub: "Two people. Endless possibilities.",
    icon: "people",
  },
  {
    id: "game_show",
    label: "Game Show",
    sub: "Big energy, quick thinking.",
    icon: "mic",
  },
  {
    id: "scene_lab",
    label: "Scene Lab",
    sub: "Make something from nothing.",
    icon: "theater",
  },
  {
    id: "improv_gym",
    label: "Improv Gym",
    sub: "Stretch your imagination.",
    icon: "practice",
  },
] as const;

export const CuratedSceneSchema = z.object({
  id: z.string(),
  originalText: z.string(),
  source: z.object({
    id: z.string(),
    category: z.string(),
    version: z.number().int(),
    packVersion: z.string(),
  }),
  ingredients: z.array(
    z.object({
      category: z.string(),
      id: z.string(),
      version: z.number().int(),
    }),
  ),
  originalRoles: z.array(z.string()).optional(),
  originalExpandableRole: z.string().nullable().optional(),
});
export const curatedScenes = z.array(CuratedSceneSchema).parse(curated);
