import { readdir, writeFile, readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
async function files(path = "dist") {
  const all = [];
  for (const d of await readdir(path, { withFileTypes: true })) {
    const p = path + "/" + d.name;
    if (d.isDirectory()) all.push(...(await files(p)));
    else all.push(p);
  }
  return all;
}
await writeFile("dist/_redirects", "/* /index.html 200\n");
let html = await readFile("dist/index.html", "utf8");
html = html.replace(
  /<title>.*?<\/title>/,
  "<title>Off Script — Make it up as you go.</title>",
);
if (!html.includes("<title>"))
  html = html.replace(
    "</head>",
    "<title>Off Script — Make it up as you go.</title></head>",
  );
// Render a tiny brand shell before the deferred application bundle arrives.
const lockup = await readFile("public/brand/lockup.svg", "utf8");
html = html.replace(
  '<div id="root"></div>',
  `<div id="root"><div role="status" aria-live="polite" class="boot">${lockup}<p>Getting the games ready…</p></div></div>`,
);
html = html.replace(
  "</head>",
  `<style>.boot{display:flex;flex:1;flex-direction:column;align-items:center;justify-content:center;gap:14px;background:#F8F6F1;color:#555F70;font:16px/1.5 system-ui,sans-serif}.boot svg{width:200px;height:40px}.boot p{margin:0}@media(prefers-reduced-motion:no-preference){.boot{animation:appear .2s ease-out}@keyframes appear{from{opacity:0}to{opacity:1}}}</style></head>`,
);
const fontPaths = (await files()).filter((p) => p.endsWith(".woff2"));
const preloads = fontPaths
  .map(
    (p) =>
      `<link rel="preload" href="/${p.slice(5)}" as="font" type="font/woff2" crossorigin="anonymous">`,
  )
  .join("");
html = html.replace("</head>", preloads + "</head>");
const origin = "https://off-script-play.lindsey08092.chatgpt.site";
html = html.replace(
  "</head>",
  `<meta name="description" content="Improv party games for 2–12 people. Quick riffs with friends or focused practice. One phone, no account."><meta property="og:title" content="Off Script — Less overthinking. More making it up."><meta property="og:description" content="Hosted Party Night, flexible Prompt Studio, and 39 improv games. One phone. 2–12 people."><meta property="og:type" content="website"><meta property="og:url" content="${origin}"><meta property="og:image" content="${origin}/share-card.png?v=brand-2"><meta property="og:site_name" content="Off Script"><meta property="og:locale" content="en_US"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="Off Script. Less overthinking. More making it up. Improv party games for 2–12 people."><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="Off Script — Make it up as you go."><meta name="twitter:description" content="Quick riffs with friends or focused improv practice. One phone. 2–12 people."><meta name="twitter:image" content="${origin}/share-card.png?v=brand-2"><meta name="twitter:image:alt" content="Off Script improv party games"><link rel="canonical" href="${origin}/"><link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/icon-192.png"><meta name="theme-color" content="#172B49"></head>`,
);
await writeFile("dist/index.html", html);

const paths = (await files())
  .filter((p) => !p.endsWith("sw.js"))
  .map((p) => "/" + p.slice(5));
const digest = createHash("sha256");
for (const path of paths) {
  digest.update(path);
  digest.update(await readFile("dist" + path));
}
const version = digest.digest("hex").slice(0, 12);
await writeFile(
  "dist/sw.js",
  `const CACHE='off-script-${version}';const ASSETS=${JSON.stringify(paths)};self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('off-script-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(u.origin!==self.location.origin||e.request.method!=='GET')return;if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match('/index.html')));return;}e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)))})`,
);

console.log(`Offline cache ${version}: ${paths.length} local files`);
