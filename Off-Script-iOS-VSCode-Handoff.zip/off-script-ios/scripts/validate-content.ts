import reviewedIngredients from "../content/editorial/ingredient-purity-2.3.0.json";
import { partyRecipes, activityExperiences } from "../src/domain/party-recipes";
import {
  activities,
  categories,
  curatedScenes,
  goals,
  prompts,
  quirks,
  relationships,
  topics,
} from "../src/domain/content";
const assert = (value: unknown, message: string) => {
  if (!value) throw Error(message);
};
const counts = {
  relationship: 80,
  location: 70,
  profession: 50,
  role: 65,
  emotion: 50,
  action: 65,
  situation: 65,
  object: 60,
  genre: 25,
  opening_line: 70,
};
assert(activities.length === 39, "Must include exactly 39 games");
assert(
  new Set(activities.map((a) => a.id)).size === 39,
  "Duplicate activity ID",
);
for (const [family, n] of Object.entries({
  punchline: 6,
  performance: 11,
  scene: 9,
  drill: 8,
  social: 5,
}))
  assert(
    activities.filter((a) => a.family === family).length === n,
    `Wrong ${family} count`,
  );
for (const category of categories) {
  const pool = prompts.filter((p) => p.category === category);
  assert(pool.length >= counts[category], `Too few ${category} prompts`);
  assert(
    new Set(pool.map((p) => p.text.toLowerCase().trim())).size === pool.length,
    `Duplicate ${category} content`,
  );
}
for (let n = 2; n <= 12; n++)
  assert(
    relationships.some((r) => r.minPlayers <= n && r.maxPlayers >= n),
    `No relationship for ${n}`,
  );
for (const pool of [activities, prompts, relationships, topics, goals, quirks])
  assert(
    new Set(pool.map((p) => p.id)).size === pool.length,
    "Duplicate content ID",
  );
assert(
  topics.length >= 160 && topics.every((t) => t.plural),
  "160 topics with authored plurals required",
);
assert(goals.length >= 60, "60 objectives required");
assert(quirks.length >= 40, "40 quirks required");
assert(
  prompts.filter((p) =>
    ["emotion", "genre", "opening_line"].includes(p.category),
  ).length >= 50,
  "50 cues required",
);
assert(
  !prompts.some((p) => /scenario \d+|placeholder|lorem ipsum/i.test(p.text)),
  "Placeholder content",
);
console.log(
  JSON.stringify(
    {
      games: activities.length,
      studio: prompts.length,
      relationships: relationships.length,
      topics: topics.length,
      goals: goals.length,
      quirks: quirks.length,
      cueEntries: prompts.filter((p) =>
        ["emotion", "genre", "opening_line"].includes(p.category),
      ).length,
    },
    null,
    2,
  ),
);

for (const example of curatedScenes) {
  assert(example.originalText.length > 0, "Missing archived original");
  assert(
    new Set(example.ingredients.map((ref) => ref.category)).size ===
      example.ingredients.length,
    "Two ingredients for one category in curated example",
  );
  for (const ref of example.ingredients)
    assert(
      prompts.some(
        (p) =>
          p.id === ref.id &&
          p.category === ref.category &&
          p.version === ref.version,
      ),
      `Broken curated ingredient reference ${ref.id}`,
    );
}
for (const p of prompts.filter((p) => p.category === "relationship")) {
  const template = relationships.find((r) => r.id === p.relationshipTemplateId);
  assert(
    template && template.premise === p.text,
    `Missing pure relationship template ${p.id}`,
  );
}
console.log(
  `${curatedScenes.length} preserved combined examples with valid versioned links`,
);

assert(
  new Set(partyRecipes.map((r) => r.pattern)).size === 9,
  "Missing party presentation pattern",
);
assert(
  Object.keys(activityExperiences).length === 39,
  "Missing activity experience metadata",
);
console.log(
  `${partyRecipes.length} party recipes across ${new Set(partyRecipes.map((r) => r.activityId)).size} activities; all 9 patterns`,
);

const approved = new Map(
  reviewedIngredients.approvedValues.map((p) => [p.id, p]),
);
assert(
  prompts.length === approved.size,
  "Ingredient changes need an editorial review update",
);
for (const p of prompts) {
  const reviewed = approved.get(p.id);
  assert(
    reviewed &&
      reviewed.text === p.text &&
      reviewed.category === p.category &&
      reviewed.version === p.version,
    `Ingredient needs editorial review: ${p.id}`,
  );
}
console.log(
  "Every live ingredient matches the complete category-purity review",
);
