import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import { resolve, extname } from "node:path";
const root = resolve("dist");
const port = Number(process.env.OFFSCRIPT_TEST_PORT ?? 4173);
const types = {
  ".html": "text/html",
  ".js": "application/javascript",
  ".css": "text/css",
  ".json": "application/json",
  ".ttf": "font/ttf",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};
http
  .createServer(async (req, res) => {
    try {
      const pathname = decodeURIComponent(
        new URL(req.url, "http://localhost").pathname,
      );
      let p = resolve(root, "." + pathname);
      if (!p.startsWith(root + "/") && p !== root) {
        res.writeHead(403);
        res.end();
        return;
      }
      try {
        if (!(await stat(p)).isFile()) p = root + "/index.html";
      } catch {
        if (extname(pathname)) {
          res.writeHead(404);
          res.end();
          return;
        }
        p = root + "/index.html";
      }
      const bytes = await readFile(p);
      res.writeHead(200, {
        "Content-Type": types[extname(p)] ?? "application/octet-stream",
        "Cache-Control": "no-cache",
      });
      res.end(bytes);
    } catch {
      res.writeHead(500);
      res.end("Unable to load app");
    }
  })
  .listen(port, "0.0.0.0", () =>
    console.log(`Off Script export at http://localhost:${port}`),
  );
