# Current native handoff

Read [START_HERE_IOS.md](../START_HERE_IOS.md), [verification](ios/VERIFICATION.md) and [release checklist](ios/RELEASE_CHECKLIST.md) for current setup. `app.config.ts` resolves public owner metadata from `.env.local`/app.json/EAS environments. `npm run ios:check -- --release` identifies missing values.

The older readiness list below remains useful background; its original unexecuted prebuild/export statements are superseded only by the specific checks recorded in ios/VERIFICATION.md. No native compile, signing, physical-device test or TestFlight upload is claimed.

# Apple release readiness

Implemented: shared Expo app and icon/splash assets, offline catalogs, no account/runtime backend, native SQLite adapter, iOS Hermes export, EAS development/preview/production profiles, local privacy/deletion UI, clean defaults and explicit optional 18+ gating.

Not executed: an Xcode native compile, simulator session, physical iPhone/iPad session, VoiceOver audit, Dynamic Type audit, native airplane-mode/reinstall/background tests, Ring/Silent/speech/haptic validation, IPA signing, TestFlight upload, or App Store submission. Linux has no Apple runtime. The real SQLite SQL test uses a Node SQLite bridge and is not an iOS native-bridge test.

Owner actions before distribution:

- Confirm the OFF SCRIPT name, trademark rights, and App Store availability.
- Supply the Apple team, owner-selected bundle identifier, EAS project/account and authorized signing access. Set ios.bundleIdentifier in app.json. Do not commit signing assets or account credentials.
- Provide real approved public support/privacy URLs and support contact. The in-app privacy notice exists; no public legal URL/contact was fabricated.
- Review age rating and optional suggestive-content treatment. Everyone playing must consent; classroom clean always overrides opt-in.
- Run the physical-device QA matrix, especially background restore, silent mode, local deletion, 2-person automatic play and 8-person display.
- Prepare owner-reviewed store metadata/screenshots/privacy disclosures. Check hosting/Expo dependencies' actual network behavior before final privacy declarations.

Commands after owner configuration:

```bash
npx expo-doctor
npx eas-cli@latest build --platform ios --profile preview
npx eas-cli@latest build --platform ios --profile production
npx eas-cli@latest submit --platform ios
```

Preview profile targets simulator. Production profile is for an owner-signed store build. TestFlight upload is distinct from App Store approval. Obtain owner approval before final public App Store review submission.
