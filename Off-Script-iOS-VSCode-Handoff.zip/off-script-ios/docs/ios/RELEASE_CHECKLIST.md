# Native release checklist

## Owner configuration

- Use the owner's Apple Developer and Expo/EAS accounts; establish the actual app name/rights, bundle ID and App Store Connect record.
- Fill public metadata in `.env.local`/app.json and in the appropriate EAS environments. Run `npm run ios:check -- --release`.
- Host an approved public privacy policy and support page with a real contact path. The native app exposes those configured links in Settings. Both App Store metadata and in-app privacy access are required.
- Review the App Store age/content questionnaire against the entire available app, including optional suggestive adult comedy; default Clean mode is not a reason to omit that content from disclosures.

## Native build and privacy

- Run `npm ci`, typecheck, content validation, tests and Expo Doctor with the lockfile.
- Build with Xcode or EAS. This package's source is not a signed IPA.
- Inspect the actual archive's Info.plist, entitlements and aggregated PrivacyInfo.xcprivacy. No camera, microphone, location, contacts or tracking permission is needed for the current game experience. Development-client local-network behavior is distinct from the production app.
- The app manifest declares no tracking/developer data collection. React Native/Expo dependencies supply required-reason API declarations; the generated Podfile keeps privacy-manifest aggregation enabled. CocoaPods/Xcode must perform and verify the final aggregation.
- Current native source uses OS-provided cryptography; the encryption exemption flag is set accordingly. Reassess if the product adds custom/non-exempt encryption.
- Inspect release network behavior, SDK manifests and any user-initiated support/feedback transmission before completing App Store privacy answers. Do not infer the final privacy label solely from a default manifest.
- Check the generated AppIcon asset has the required 1024-square opaque rendition; Expo performs native icon generation from the provided source.

## Physical-device acceptance

- New group: 2–12 optional names → card → Next without repeated setup; returning group one-tap fresh deck; rename/add/remove and archived names remain correct.
- Prompt Studio: each category alone stays pure; selected-category-only composition; locks/rerolls; saved originals; Connected/Mix Freely; native share-sheet behavior.
- Airplane mode from a clean install of a signed native build; bundled fonts and all catalogs work without a first web visit.
- Background/lock/unlock/force quit: timers pause, private roles cover, exact sessions restore safely. Verify real native SQLite bridge behavior and app updates without losing data.
- Ring/Silent/no-audio: all cues remain visually/manual usable. Optional speech/haptics must fail gracefully.
- VoiceOver, Dynamic Type, Reduce Motion, dark/light, keyboard, safe areas, landscape, small iPhone and supported iPad layouts.
- Privacy/Support links open their real pages; Clear all local data clears names/history/favorites/preferences and retains games. Document OS backups honestly.

## Distribution

- Complete real App Store metadata, policy URLs, support contact, screenshots and age/privacy answers.
- Upload the signed production build to TestFlight; test the actual binary. Record crash/lifecycle/accessibility results.
- Have the owner review the concrete build/metadata and make the final App Review/release decision. A TestFlight upload, a JavaScript export and an App Store approval are separate outcomes.
