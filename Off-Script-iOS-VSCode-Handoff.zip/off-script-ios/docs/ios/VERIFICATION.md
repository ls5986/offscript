# iOS handoff verification

Prepared on 2026-10-16 from the public app's `fc7fff3235145a4eaee70177f65a3207e6dc2871` revision, in the separate `ios-handoff` branch. The live website was not changed or redeployed for this work.

## Completed checks

| Check | Result |
| --- | --- |
| TypeScript | Passed |
| Unit/storage/configuration tests | 100 passed across 9 files |
| Lint | Passed |
| Expo Doctor | All 20 checks passed after compatible SDK 58 patch updates |
| Content validation | Passed: 39 games, 1,182 ingredients, 463 preserved curated examples, 31 Party recipes |
| iOS project generation | `expo prebuild --platform ios --no-install --clean` passed |
| iOS JavaScript/Hermes export | Passed; one approximately 4.1 MB entry bundle |
| Production web export | Passed |
| Browser regression | 11 passed: Party Night, Studio composition/saves and delayed-font startup |
| Development release check | Reports the four missing owner values without blocking local development |
| Strict release check without owner metadata | Correctly exits unsuccessfully; prevents accidental production configuration |
| Production configuration with temporary test values | Resolves expected bundle ID, guest/local mode and privacy settings |
| Whitespace/diff check | Passed |

Browser tests used this handoff's exported build on port 4174, independently of the original website checkout. They are browser coverage, not native device tests.

The generated native project defaults to iOS 16.4. The generated 1024 × 1024 AppIcon is opaque RGB. Generated Info.plist disables file sharing/document opening, marks current OS-provided cryptography as exempt, and does not request camera or microphone access. The Podfile retains privacy-manifest aggregation. Required-reason API declarations exist in dependency manifests, but their final CocoaPods/Xcode aggregate has not been produced or certified here.

Temporary validation identifiers were supplied only to local configuration/prebuild commands. They are not owner registrations, credentials, policy pages or distributable app identities. Generated native projects and export/build output are excluded from the source ZIP.

## Still required before release

This environment did not run CocoaPods, Xcode, a signed native compile, a physical iPhone installation, TestFlight upload or App Review. A Hermes export and native project generation do not prove that a signed iOS binary has passed those steps.

The owner must supply the actual Apple/Expo project metadata and public privacy/support pages, then complete the [release checklist](RELEASE_CHECKLIST.md). Verify the real SQLite bridge, airplane-mode startup, lifecycle/private-role protection, accessibility, final privacy manifests and production network behavior on the built app. No account backend or Sign in with Apple service has been provisioned; the first release deliberately uses guest play and local saves.
