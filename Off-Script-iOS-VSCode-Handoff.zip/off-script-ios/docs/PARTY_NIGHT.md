# Off Script 1.3 — Party Night and Prompt Studio

Party Night and Prompt Studio lead a compact app Home. Explore shows all eligible games immediately (38 Clean, plus the optional adult format). Quick games, group size, experience, skill search, movement and family are optional filters, not a prerequisite identity choice.

First-time Party Night: 2–12 people → optional names → Deal first card. Returning: Start Party Night deals a fresh Clean deck with the remembered group in one tap; Change players opens setup separately. Resume continues an existing card. No account, mandatory scoring, duration or skill selection.

## Cards and pacing

A card shows people first, activity, creative input and a short instruction. New Word/New Prompt sits beside Next Card. Skip, Pause and How to Play are visible. Turn-based cards offer optional named turn guidance, Next turn and Pass turn. Cue scenes offer a Start action, automatic visual cues and a manual cue button. Sound and timers are optional. Reaching zero never deals another card.

The balanced default deck mixes quick jokes/stories/social games with occasional short scenes: a short scene appears within each five-card stretch when compatible. A scene is followed by a quick card. Movement is off; secret-role games remain manually selectable. Turn off Mix in short scenes for an entirely untimed automatic deck. Advanced and instructor-led formats remain in Explore.

31 recipes reference 23 existing activities and all nine participation patterns. One shared engine selects compatible cards with deterministic randomness, recent-history suppression and fair participant/pair assignment. Optional team turns alternate teams on suitable joke/open-mic cards without requiring points. Team names and membership can be changed in Players.

## People, host controls and persistence

The People button opens in-session player controls: pass, sit out/rejoin, rename, add or remove. New people receive new IDs; removed people remain archived for historical cards. A changed membership deals a fresh Clean card and clears adult confirmation. Renaming preserves the current card. Card-time names are retained for recap history. Players remain editable between cards without repeating setup.

Large Display enlarges the shared card. Pause, cues, optional timer restart/disable, Replay, choose a game, Save & leave and End Session remain available. Private handoffs cover on background/navigation/reload and after a 20-second reveal timeout. Finished sessions cannot be reactivated by navigation cleanup.

Exact prompts, favorites, sessions and feedback use the shared local repository: IndexedDB on web and SQLite on native. Optional fields/defaults preserve old saved data. SQLite rewrites the current seat projection safely when players change, retains archived player records and keeps historical rounds/participants. No server, account, cloud sync or runtime AI is needed for the single-phone experience.

Feedback uses the same four choices in Party Night, individual games and Studio. It stays on the device and is exportable in Settings. Prompt feedback retains the exact snapshot.

## Prompt Studio and content

One category returns only its pure ingredient. Multiple categories use deterministic, concise composition with exact ingredient values and source versions stored separately. Locks and rerolls keep other ingredients fixed. Independent clauses and other awkward joins remain visible separately rather than being forced into an unnatural sentence. Party cards also show any ingredient outside their composed premise, including initial Emotion Remote emotions.

All 463 original combined examples remain curated relationships between ingredients. Studio handoff launches Scene Lab directly using the already-selected count and exact snapshot. A chosen individual game can reuse a compatible remembered group directly; setup otherwise permits numbered fallback names, with Free play/Rounds and names in optional disclosures.

Pack 2.3.0 includes 1,182 ingredients, 96 neutral relationship templates, 160 joke words, 60 secret objectives and 40 quirks. This update adds 94 ingredients: short social observations, first-person advice problems and dating/flirting material across eight Spicy formats. Card instructions retain the actual rules (three lines, association, echo, shared memory, mirroring, etc.). See [CARD_EDITORIAL_SAMPLE.md](CARD_EDITORIAL_SAMPLE.md) for all 31 generated recipe samples; editorial review does not establish how funny unfamiliar groups find them.

## Native release limits

Shared native components, SQLite, EAS profiles and Hermes export remain supported. This workspace does not provide an Apple simulator, physical iPhone, signing or TestFlight distribution. Those checks are separate from the public web release.
