import { expect, test } from "@playwright/test";

test("Home and game setup remain usable while web fonts are still downloading", async ({
  page,
}) => {
  let releaseFonts: () => void = () => {};
  const pendingFonts = new Promise<void>((resolve) => {
    releaseFonts = resolve;
  });
  await page.route("**/*.woff2", async (route) => {
    await pendingFonts;
    await route.continue();
  });
  try {
    await page.goto("/", { waitUntil: "domcontentloaded" });
    const start = page.getByRole("button", {
      name: "Start Party Night",
      exact: true,
    });
    await expect(start).toBeEnabled();
    await start.click();
    await expect(
      page.getByRole("button", { name: "Deal first card", exact: true }),
    ).toBeVisible();
  } finally {
    releaseFonts();
  }
});
