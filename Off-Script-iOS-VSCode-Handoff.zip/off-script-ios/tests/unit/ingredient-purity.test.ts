import { expect, test } from "vitest";
import review from "../../content/editorial/ingredient-purity-2.3.0.json";
import aliases from "../../src/content/v2/ingredient-aliases.json";
import {
  categories,
  curatedScenes,
  PACK,
  prompts,
  relationships,
} from "../../src/domain/content";
import {
  legacyIngredientCategories,
  upgradeSnapshotIngredients,
} from "../../src/domain/composer";
import { emptyPrompt, generatePrompt } from "../../src/domain/prompts";
import {
  RelationshipTemplateSchema,
  type PromptSnapshot,
} from "../../src/domain/contracts";
import { seededRng } from "../../src/domain/random";
const canonical = (id: string) => (aliases as Record<string, string>)[id] ?? id;
const snapshot = (
  id: string,
  text: string,
  category: string,
  version: number,
  locked = false,
): PromptSnapshot => ({
  ...emptyPrompt(),
  contentPackVersion: review.sourcePackVersion,
  entries: {
    [category]: {
      id,
      text,
      locked,
      sourceVersion: version,
      sourcePackVersion: review.sourcePackVersion,
    },
  },
});
test("the entire generated ingredient library and all relationship templates have explicit editorial review coverage", () => {
  expect(review.reviewedIngredientIds).toHaveLength(1075);
  expect(new Set(review.approvedValues.map((p) => p.category))).toEqual(
    new Set(categories),
  );
  expect(
    prompts.map(({ id, category, text, version }) => ({
      id,
      category,
      text,
      version,
    })),
  ).toEqual(review.approvedValues);
  expect(relationships.map((r) => r.id)).toEqual(
    review.reviewedRelationshipTemplateIds,
  );
  expect(relationships).toEqual(
    review.approvedRelationshipTemplates.map((r) =>
      RelationshipTemplateSchema.parse(r),
    ),
  );
  const teammates = relationships.find(
    (r) => r.premise === "Former teammates",
  )!;
  expect(teammates.namedRoles).toEqual([
    "First former teammate",
    "Second former teammate",
  ]);
});
test("every corrected ingredient generates alone without reintroducing its optional scene details", () => {
  for (const row of review.corrections) {
    const p = prompts.find((p) => p.id === canonical(row.id))!;
    expect(p.text.toLowerCase()).toBe(row.after.toLowerCase());
    const s = generatePrompt(
      {
        categories: [p.category],
        count: 2,
        style: "coherent",
        flavor: p.flavor,
        contentLevel: "18_plus",
        pool: [p],
      },
      seededRng(1),
    ).snapshot;
    expect(Object.keys(s.entries)).toEqual([p.category]);
    expect(s.entries[p.category].text).toBe(p.text);
    expect(s.composition).toBeUndefined();
  }
});
test("all corrected historical values remain archived and upgrade only the selected category; locked originals remain exact", () => {
  for (const row of review.corrections) {
    const original = snapshot(
      row.id,
      row.before,
      row.category,
      row.sourceVersion,
    );
    const saved = structuredClone(original);
    expect(
      curatedScenes.some(
        (c) => c.source.id === row.id && c.originalText === row.before,
      ),
    ).toBe(true);
    expect(legacyIngredientCategories(original)).toEqual([row.category]);
    const updated = upgradeSnapshotIngredients(original);
    expect(Object.keys(updated.entries)).toEqual([row.category]);
    expect(updated.entries[row.category].id).toBe(canonical(row.id));
    expect(updated.entries[row.category].text.toLowerCase()).toBe(
      row.after.toLowerCase(),
    );
    expect(updated.entries[row.category].sourcePackVersion).toBe(PACK);
    expect(original).toEqual(saved);
    const locked = {
      ...original,
      entries: {
        [row.category]: { ...original.entries[row.category], locked: true },
      },
    };
    expect(upgradeSnapshotIngredients(locked)).toEqual(locked);
  }
});
test("several historical values for the same ID are all recognized, with other locked ingredients unchanged", () => {
  const history = curatedScenes.filter(
    (c) => c.source.id === "prompt_action_076",
  );
  expect(new Set(history.map((c) => c.originalText)).size).toBeGreaterThan(1);
  for (const h of history) {
    const old = snapshot(
      h.source.id,
      h.originalText,
      "action",
      h.source.version,
    );
    old.entries.location = {
      id: "prompt_location_077",
      text: "A hotel lobby",
      locked: true,
      sourceVersion: 2,
      sourcePackVersion: "2.0.0",
    };
    const saved = structuredClone(old);
    const result = upgradeSnapshotIngredients(old);
    expect(result.entries.action.text).toBe("Wrapping a spoon");
    expect(result.entries.location).toEqual(saved.entries.location);
    expect(Object.keys(result.entries).sort()).toEqual(["action", "location"]);
    expect(old).toEqual(saved);
  }
});
